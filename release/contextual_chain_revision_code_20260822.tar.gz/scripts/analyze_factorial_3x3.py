import math
from pathlib import Path
from statistics import NormalDist
import numpy as np
import pandas as pd
from scipy import stats

BASE = Path(__file__).resolve().parent / 'factorial_3x3_main_step7'
OUT = Path(__file__).resolve().parent / 'factorial_3x3_analysis_step8'
OUT.mkdir(exist_ok=True)
RAW = BASE / 'raw_factorial_3x3.csv'
B = 5000
Z = NormalDist().inv_cdf(0.975)

def wilson(k, n):
    p = k / n
    den = 1 + Z*Z/n
    center = (p + Z*Z/(2*n)) / den
    half = Z * math.sqrt(p*(1-p)/n + Z*Z/(4*n*n)) / den
    return center-half, center+half

def bootstrap_mean_p95(x, seed):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(B, len(x)))
    s = x[idx]
    means = s.mean(axis=1)
    p95 = np.quantile(s, 0.95, axis=1, method='linear')
    return np.quantile(means, [.025,.975]), np.quantile(p95, [.025,.975])

def paired_binary(a, b, seed):
    a = np.asarray(a, int); b = np.asarray(b, int); d = a-b
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(d), size=(B,len(d)))
    boot = d[idx].mean(axis=1)
    n10 = int(np.sum((a==1)&(b==0)))
    n01 = int(np.sum((a==0)&(b==1)))
    disc = n10+n01
    p = stats.binomtest(min(n10,n01), n=disc, p=.5, alternative='two-sided').pvalue if disc else 1.0
    lo,hi = np.quantile(boot,[.025,.975])
    return d.mean(),lo,hi,n10,n01,p

def paired_cont(a,b,seed):
    a=np.asarray(a,float); b=np.asarray(b,float); d=a-b
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(d),size=(B,len(d)))
    bd=d[idx]
    mean_boot=bd.mean(axis=1)
    qa=np.quantile(a[idx],.95,axis=1,method='linear')
    qb=np.quantile(b[idx],.95,axis=1,method='linear')
    mlo,mhi=np.quantile(mean_boot,[.025,.975])
    qlo,qhi=np.quantile(qa-qb,[.025,.975])
    p=stats.wilcoxon(d,zero_method='wilcox',alternative='two-sided',method='asymptotic').pvalue if np.any(d!=0) else 1.0
    return d.mean(),mlo,mhi,np.quantile(a,.95)-np.quantile(b,.95),qlo,qhi,p

def boot_vector_mean(d,seed):
    d=np.asarray(d,float)
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(d),size=(B,len(d)))
    boot=d[idx].mean(axis=1)
    lo,hi=np.quantile(boot,[.025,.975])
    return d.mean(),lo,hi

df=pd.read_csv(RAW)
fac=df[df.is_factorial==1].copy()

# Core integrity assertion used by the statistical interpretation.
key_metrics=['success_end','recovered','recovery_time_s','heads_equal_end','max_reorg_depth','max_fork_peak',
             'gossip_budget_pair_draws','gossip_pairs','gossip_blocks_sent','total_bytes_est']
full=fac[fac.head_label=='Full'].sort_values(['case','sync_label','seed']).reset_index(drop=True)
branch=fac[fac.head_label=='BranchScoreOnly'].sort_values(['case','sync_label','seed']).reset_index(drop=True)
assert len(full)==len(branch)==6000
assert (full[['case','sync_label','seed']].values == branch[['case','sync_label','seed']].values).all()
for c in key_metrics:
    assert np.allclose(full[c].astype(float), branch[c].astype(float), equal_nan=True), c

# Cell-level statistics.
rows=[]
seed=1000
for case,g in fac.groupby('case'):
    for (head,sync),h in g.groupby(['head_label','sync_label']):
        n=len(h); k=int(h.success_end.sum()); flo,fhi=wilson(k,n)
        mci,pci=bootstrap_mean_p95(h.recovery_time_s.values, seed); seed+=1
        rows.append(dict(case=case,head=head,sync=sync,n=n,
                         final_agreement=k/n,fa_ci_lo=flo,fa_ci_hi=fhi,
                         recovery_mean_s=h.recovery_time_s.mean(),rec_mean_ci_lo=mci[0],rec_mean_ci_hi=mci[1],
                         recovery_p95_s=h.recovery_time_s.quantile(.95),rec_p95_ci_lo=pci[0],rec_p95_ci_hi=pci[1],
                         budget_pair_draws=h.gossip_budget_pair_draws.mean(),
                         preexchange_pairs=h.gossip_pairs.mean(),gossip_blocks_sent=h.gossip_blocks_sent.mean()))
cell=pd.DataFrame(rows).sort_values(['case','sync','head'])
cell.to_csv(OUT/'factorial_cell_statistics.csv',index=False)

def get(case,head,sync,metric):
    h=fac[(fac.case==case)&(fac.head_label==head)&(fac.sync_label==sync)].sort_values('seed')
    return h[metric].to_numpy()

# Planned paired contrasts.
rows=[]; seed=3000
for case in sorted(fac.case.unique()):
    for sync in ['FixedLow','FixedHigh','Adaptive']:
        bs=paired_binary(get(case,'HeightOnly',sync,'success_end'),get(case,'Full',sync,'success_end'),seed); seed+=1
        cs=paired_cont(get(case,'HeightOnly',sync,'recovery_time_s'),get(case,'Full',sync,'recovery_time_s'),seed); seed+=1
        rows.append([case,'Head: HeightOnly - Full',sync,*bs,*cs])
    for head in ['Full','HeightOnly','BranchScoreOnly']:
        for sa,sb,label in [('FixedHigh','FixedLow','Sync: FixedHigh - FixedLow'),
                            ('Adaptive','FixedLow','Sync: Adaptive - FixedLow'),
                            ('Adaptive','FixedHigh','Sync: Adaptive - FixedHigh')]:
            bs=paired_binary(get(case,head,sa,'success_end'),get(case,head,sb,'success_end'),seed); seed+=1
            cs=paired_cont(get(case,head,sa,'recovery_time_s'),get(case,head,sb,'recovery_time_s'),seed); seed+=1
            rows.append([case,label,head,*bs,*cs])
cols=['case','contrast','stratum','fa_diff','fa_ci_lo','fa_ci_hi','fa_n10','fa_n01','fa_mcnemar_p',
      'mean_rec_diff_s','mean_rec_ci_lo','mean_rec_ci_hi','p95_rec_diff_s','p95_rec_ci_lo','p95_rec_ci_hi','rec_wilcoxon_p']
contr=pd.DataFrame(rows,columns=cols)
contr.to_csv(OUT/'paired_planned_contrasts.csv',index=False)

# Nonredundant main effects/interactions: Full and HeightOnly only, because BranchScoreOnly == Full exactly.
rows=[]; seed=6000
for case in sorted(fac.case.unique()):
    Yfa={(h,s):get(case,h,s,'success_end').astype(float) for h in ['Full','HeightOnly'] for s in ['FixedLow','FixedHigh','Adaptive']}
    Yrt={(h,s):get(case,h,s,'recovery_time_s').astype(float) for h in ['Full','HeightOnly'] for s in ['FixedLow','FixedHigh','Adaptive']}
    dfa=np.mean(np.vstack([Yfa[('HeightOnly',s)]-Yfa[('Full',s)] for s in ['FixedLow','FixedHigh','Adaptive']]),axis=0)
    drt=np.mean(np.vstack([Yrt[('HeightOnly',s)]-Yrt[('Full',s)] for s in ['FixedLow','FixedHigh','Adaptive']]),axis=0)
    rows.append([case,'Head main: HeightOnly - Full','final_agreement_pp',*boot_vector_mean(dfa,seed)]); seed+=1
    rows.append([case,'Head main: HeightOnly - Full','mean_recovery_s',*boot_vector_mean(drt,seed)]); seed+=1
    for sa,sb,label in [('FixedHigh','FixedLow','Sync main: FixedHigh - FixedLow'),
                        ('Adaptive','FixedLow','Sync main: Adaptive - FixedLow'),
                        ('Adaptive','FixedHigh','Sync main: Adaptive - FixedHigh')]:
        dfa=np.mean(np.vstack([Yfa[(h,sa)]-Yfa[(h,sb)] for h in ['Full','HeightOnly']]),axis=0)
        drt=np.mean(np.vstack([Yrt[(h,sa)]-Yrt[(h,sb)] for h in ['Full','HeightOnly']]),axis=0)
        rows.append([case,label,'final_agreement_pp',*boot_vector_mean(dfa,seed)]); seed+=1
        rows.append([case,label,'mean_recovery_s',*boot_vector_mean(drt,seed)]); seed+=1
    for sa,sb,label in [('FixedHigh','FixedLow','Interaction: HeadEffect(FixedHigh)-HeadEffect(FixedLow)'),
                        ('Adaptive','FixedLow','Interaction: HeadEffect(Adaptive)-HeadEffect(FixedLow)'),
                        ('Adaptive','FixedHigh','Interaction: HeadEffect(Adaptive)-HeadEffect(FixedHigh)')]:
        dfa=(Yfa[('HeightOnly',sa)]-Yfa[('Full',sa)])-(Yfa[('HeightOnly',sb)]-Yfa[('Full',sb)])
        drt=(Yrt[('HeightOnly',sa)]-Yrt[('Full',sa)])-(Yrt[('HeightOnly',sb)]-Yrt[('Full',sb)])
        rows.append([case,label,'final_agreement_pp',*boot_vector_mean(dfa,seed)]); seed+=1
        rows.append([case,label,'mean_recovery_s',*boot_vector_mean(drt,seed)]); seed+=1
eff=pd.DataFrame(rows,columns=['case','effect','metric','estimate','ci_lo','ci_hi'])
mask=eff.metric.eq('final_agreement_pp')
eff.loc[mask,['estimate','ci_lo','ci_hi']]*=100
eff.to_csv(OUT/'main_effects_interactions.csv',index=False)

# Adaptive assigned-budget reduction vs fixed high.
rows=[]; seed=9000
for case in sorted(fac.case.unique()):
    h=fac[(fac.case==case)&(fac.head_label=='Full')&(fac.sync_label=='Adaptive')].sort_values('seed')
    x=h.gossip_budget_pair_draws.to_numpy(float)
    red=1-x/9600.0
    rng=np.random.default_rng(seed); seed+=1
    idx=rng.integers(0,len(x),size=(B,len(x)))
    xb=x[idx].mean(axis=1); rb=red[idx].mean(axis=1)
    rows.append(dict(case=case,adaptive_mean_pair_draws=x.mean(),pair_draws_ci_lo=np.quantile(xb,.025),pair_draws_ci_hi=np.quantile(xb,.975),
                     reduction_vs_fixed_high_pct=100*red.mean(),reduction_ci_lo_pct=100*np.quantile(rb,.025),reduction_ci_hi_pct=100*np.quantile(rb,.975),
                     adaptive_high_ticks_mean=h.adaptive_high_ticks.mean(),adaptive_low_ticks_mean=h.adaptive_low_ticks.mean()))
bud=pd.DataFrame(rows)
bud.to_csv(OUT/'adaptive_budget_efficiency.csv',index=False)

# Compact report.
lines=[]
lines.append('# Step 8 statistical analysis — 3×3 matched-seed factorial')
lines.append('')
lines.append(f'Input: {RAW.name}; factorial rows={len(fac):,}; bootstrap resamples={B:,}.')
lines.append('Full and BranchScoreOnly are exactly identical for all 6,000 matched condition-runs across the audited core metrics. Therefore a conventional three-level head-rule main-effect model is structurally redundant; inferential contrasts use Full vs HeightOnly, while Full=BranchScoreOnly is reported as a mechanistic result.')
lines.append('')
for case in sorted(fac.case.unique()):
    lines.append(f'## {case}')
    cs=cell[cell.case==case]
    for sync in ['FixedLow','FixedHigh','Adaptive']:
        for head in ['Full','HeightOnly']:
            r=cs[(cs['head']==head)&(cs['sync']==sync)].iloc[0]
            lines.append(f'- {head} / {sync}: final agreement {r.final_agreement:.3f} [{r.fa_ci_lo:.3f}, {r.fa_ci_hi:.3f}], recovery mean {r.recovery_mean_s:.1f}s [{r.rec_mean_ci_lo:.1f}, {r.rec_mean_ci_hi:.1f}], p95 {r.recovery_p95_s:.1f}s [{r.rec_p95_ci_lo:.1f}, {r.rec_p95_ci_hi:.1f}].')
    lines.append('')
    cc=contr[(contr.case==case)&(contr.contrast=='Head: HeightOnly - Full')]
    for _,r in cc.iterrows():
        lines.append(f'- Head contrast at {r.stratum}: final agreement Δ={100*r.fa_diff:+.1f} pp [{100*r.fa_ci_lo:+.1f}, {100*r.fa_ci_hi:+.1f}], mean recovery Δ={r.mean_rec_diff_s:+.1f}s [{r.mean_rec_ci_lo:+.1f}, {r.mean_rec_ci_hi:+.1f}].')
    lines.append('')
    e=eff[(eff.case==case)&eff.effect.str.startswith('Sync main')]
    for _,r in e[e.metric=='final_agreement_pp'].iterrows():
        lines.append(f'- {r.effect}: final agreement Δ={r.estimate:+.1f} pp [{r.ci_lo:+.1f}, {r.ci_hi:+.1f}].')
    for _,r in e[e.metric=='mean_recovery_s'].iterrows():
        lines.append(f'- {r.effect}: mean recovery Δ={r.estimate:+.1f}s [{r.ci_lo:+.1f}, {r.ci_hi:+.1f}].')
    b=bud[bud.case==case].iloc[0]
    lines.append(f'- Adaptive assigned pair budget: {b.adaptive_mean_pair_draws:.1f} [{b.pair_draws_ci_lo:.1f}, {b.pair_draws_ci_hi:.1f}], a {b.reduction_vs_fixed_high_pct:.1f}% [{b.reduction_ci_lo_pct:.1f}, {b.reduction_ci_hi_pct:.1f}] reduction vs FixedHigh=9600.')
    lines.append('')
lines.append('## Interpretation guardrails')
lines.append('- The dominant reproducible effect is synchronization provisioning: FixedHigh and Adaptive improve final agreement by roughly 22–30 percentage points over FixedLow and reduce mean recovery by roughly 92–118 s, depending on case/head rule.')
lines.append('- Adaptive and FixedHigh are statistically close in the matched comparisons: their final-agreement and mean-recovery confidence intervals for paired differences include zero in both cases, while Adaptive assigns about 28.6–28.7% fewer pair draws.')
lines.append('- Head-rule effects are small and inconsistent across synchronization policies/cases; the data do not establish a recovery advantage for Full over HeightOnly. In some cells HeightOnly is numerically or significantly better.')
lines.append('- Because Full and BranchScoreOnly are exactly equivalent in the current height-epoch/no-sticky configuration, that equality should be presented as confirmation that the epoch label contributes no independent ordering information in the main configuration.')
lines.append('- The current factorial still does not provide an equal-total-budget fixed schedule matched to the Adaptive mean budget. Such a control would be the cleanest next experiment for testing whether timing/adaptivity itself adds value beyond total synchronization effort.')
(OUT/'step8_statistical_report.md').write_text('\n'.join(lines),encoding='utf-8')
print('Wrote', OUT)
print(cell[['case','head','sync','final_agreement','fa_ci_lo','fa_ci_hi','recovery_mean_s','recovery_p95_s']].to_string(index=False))
