#!/usr/bin/env python3
"""Equal-total-budget control for the Contextual Chain synchronization experiment.

Purpose
-------
For each Case x seed, first generate the native Full+Adaptive schedule with conservative
head switching disabled. Let that schedule contain T connected gossip ticks and total
assigned pair budget B. Construct an OFFLINE fixed-matched schedule with the same T and
exactly the same total B, but spread B as evenly as possible over all connected ticks.

We then replay:
  Head rule: Full, HeightOnly
  Timing policy: Adaptive, FixedMatched

Thus Adaptive and FixedMatched have exactly equal assigned synchronization effort within
each Case x seed; only temporal allocation differs. FixedMatched is an experimental
control, not a deployable online policy, because it uses the realized Adaptive total B
for offline matching.
"""
from __future__ import annotations

import csv, hashlib, math, os, platform, sys, time
from collections import defaultdict
from multiprocessing import Pool
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Sequence, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from sim_context_chain_v5_factorial import simulate  # type: ignore

HEAD_RULES: List[Tuple[str,str]] = [("Full","full"),("HeightOnly","height_only")]
TIMING_LABELS = ["Adaptive","FixedMatched"]
REPLAY_IDENTITY_FIELDS = [
    "converged_at_s","recovery_time_s","heads_equal_end","max_reorg_depth","max_fork_peak",
    "max_equivocations_total_max","nodes_quarantine_end","broadcast_blocks_sent",
    "broadcast_deliveries","gossip_pairs","gossip_blocks_sent","gossip_deliveries",
    "gossip_connected_ticks","gossip_budget_pair_draws","adaptive_high_ticks","adaptive_low_ticks",
    "broadcast_bytes_est","gossip_bytes_est","total_bytes_est",
]

def env_int(n,d):
    x=os.getenv(n); return d if x in {None,""} else int(x)
def env_float(n,d):
    x=os.getenv(n); return d if x in {None,""} else float(x)
def env_str(n,d):
    x=os.getenv(n); return d if x in {None,""} else x
def env_bool(n,d):
    x=os.getenv(n)
    if x in {None,""}: return d
    return x.strip().lower() in {"1","true","yes","y","on"}

def parse_cases(raw,n_nodes):
    out=[]; seen=set()
    for tok in raw.replace(',',' ').split():
        t=tok.lower()
        if t in {"casea","casea_50_50","50_50","50/50"}: item=("CaseA_50_50",n_nodes//2)
        elif t in {"caseb","caseb_80_20","80_20","80/20"}: item=("CaseB_80_20",int(round(.8*n_nodes)))
        else: raise ValueError(f"Unsupported case token {tok}")
        if item[0] not in seen: out.append(item); seen.add(item[0])
    return out

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def digest_schedule(s:Sequence[int])->str:
    # Supports arbitrary nonnegative pair counts robustly (not only byte-sized semantics conceptually).
    vals=bytes(int(x) for x in s)
    return hashlib.sha256(vals).hexdigest()

def balanced_uniform_schedule(total:int,ticks:int)->Tuple[int,...]:
    """Spread integer total over ticks with minimum possible per-tick variation.

    Entries are floor(total/ticks) or ceil(total/ticks), with the +1 entries distributed
    approximately evenly using an integer accumulator. Exact sum is guaranteed.
    """
    if ticks <= 0: raise ValueError("ticks must be positive")
    if total < 0: raise ValueError("total must be nonnegative")
    base, rem = divmod(total, ticks)
    out=[]; prev=0
    for i in range(ticks):
        cur=((i+1)*rem)//ticks
        out.append(base + (cur-prev))
        prev=cur
    assert len(out)==ticks and sum(out)==total
    assert max(out)-min(out) <= 1
    return tuple(out)

def percentile(vals:Iterable[float],p:float)->float:
    xs=sorted(float(x) for x in vals)
    if not xs: return float('nan')
    pos=(len(xs)-1)*p; lo=math.floor(pos); hi=math.ceil(pos)
    if lo==hi: return xs[lo]
    f=pos-lo; return xs[lo]*(1-f)+xs[hi]*f

def build_meta()->Dict[str,Any]:
    smoke=env_bool('SMOKE',False)
    n_seeds=env_int('NSEEDS',5 if smoke else 1000)
    seed_start=env_int('SEED_START',0)
    n_nodes=env_int('N_NODES',20)
    jobs=env_int('JOBS',min(max(1,os.cpu_count() or 1),5))
    direct=env_bool('DIRECT',False)
    net=env_str('NET','noisy').lower()
    if net=='noisy': dm,dj,dp=.80,.20,.02
    elif net=='clean': dm,dj,dp=.25,.10,0.0
    else: raise ValueError(net)
    common=dict(
        n_nodes=n_nodes, block_interval_s=30.0, sim_time_s=3600.0, partition=(1200.0,2400.0),
        epoch_len_blocks=30, cp_epoch_mode='height', cp_tiebreak='none', L_score_window=40,
        K_converge=30, use_quarantine=True, conservative_switching=False, adaptive_q_threshold=.25,
        net_delay_mean=env_float('NET_DELAY_MEAN',dm), net_delay_jitter=env_float('NET_DELAY_JITTER',dj),
        net_drop_p=env_float('NET_DROP_P',dp), gossip_tick_s=1.0, gossip_pairs_normal=1,
        gossip_pairs_quarantine=4, block_bytes_est=250,
    )
    return dict(smoke=smoke,n_seeds=n_seeds,seed_start=seed_start,jobs_n=jobs,direct=direct,net_mode=net,
                cases=parse_cases(env_str('EXTRA_CASES','CaseA_50_50 CaseB_80_20'),n_nodes),**common)

def kwargs(common:Dict[str,Any],a_size:int,seed:int,head_rule:str,sync_policy:str,
           replay:Sequence[int]|None=None,return_schedule:bool=False)->Dict[str,Any]:
    keys=['n_nodes','block_interval_s','sim_time_s','partition','epoch_len_blocks','cp_epoch_mode','cp_tiebreak',
          'L_score_window','K_converge','use_quarantine','conservative_switching','adaptive_q_threshold',
          'net_delay_mean','net_delay_jitter','net_drop_p','gossip_tick_s','gossip_pairs_normal',
          'gossip_pairs_quarantine','block_bytes_est']
    d={k:common[k] for k in keys}
    d.update(A_size=a_size,seed=seed,head_rule=head_rule,sync_policy=sync_policy,
             sync_schedule_replay=replay,return_sync_schedule=return_schedule)
    return d

def operational_equal(a,b):
    diffs=[]
    for k in REPLAY_IDENTITY_FIELDS:
        if a.get(k)!=b.get(k): diffs.append(f"{k}:{a.get(k)!r}!={b.get(k)!r}")
    return (not diffs,'; '.join(diffs))

def row(case,a_size,seed,head_label,timing_label,res,runtime_ms,source_hash,matched_hash):
    return dict(
        case=case,A_size=a_size,seed=seed,pair_id=f'{case}:seed{seed}',head_label=head_label,
        timing_label=timing_label,cell=f'{head_label}__{timing_label}',sync_policy=res['sync_policy'],
        conservative_switching=res['conservative_switching'],use_quarantine=res['use_quarantine'],
        success_end=int(bool(res['heads_equal_end'])),recovered=int(res['recovery_time_s'] is not None),
        recovery_time_s=res['recovery_time_s'],converged_at_s=res['converged_at_s'],
        max_reorg_depth=res['max_reorg_depth'],max_fork_peak=res['max_fork_peak'],
        gossip_connected_ticks=res['gossip_connected_ticks'],gossip_budget_pair_draws=res['gossip_budget_pair_draws'],
        gossip_pairs=res['gossip_pairs'],gossip_blocks_sent=res['gossip_blocks_sent'],
        total_bytes_est=res['total_bytes_est'],sync_schedule_len=res['sync_schedule_len'],
        sync_schedule_hash=res['sync_schedule_hash'],sync_schedule_replay_consumed=res['sync_schedule_replay_consumed'],
        adaptive_high_ticks=res['adaptive_high_ticks'],adaptive_low_ticks=res['adaptive_low_ticks'],
        adaptive_source_hash=source_hash,fixed_matched_schedule_hash=matched_hash,runtime_ms=runtime_ms,
    )

def run_bundle(job):
    case,a_size,seed,common=job
    t0=time.perf_counter()
    source=simulate(**kwargs(common,a_size,seed,'full','adaptive',return_schedule=True))
    source_ms=(time.perf_counter()-t0)*1000
    adaptive=tuple(int(x) for x in source['sync_schedule_trace'])
    ticks=len(adaptive); total=sum(adaptive)
    fixed=balanced_uniform_schedule(total,ticks)
    ah=digest_schedule(adaptive); fh=digest_schedule(fixed)
    rows=[]; full_adapt=None
    for head_label,head_rule in HEAD_RULES:
        for timing in TIMING_LABELS:
            policy='adaptive_replay' if timing=='Adaptive' else 'fixed_matched_replay'
            sched=adaptive if timing=='Adaptive' else fixed
            rt=time.perf_counter(); res=simulate(**kwargs(common,a_size,seed,head_rule,policy,replay=sched))
            ms=(time.perf_counter()-rt)*1000
            if head_label=='Full' and timing=='Adaptive': full_adapt=res
            rows.append(row(case,a_size,seed,head_label,timing,res,ms,ah,fh))
    ok,diffs=operational_equal(source,full_adapt)
    rec=dict(case=case,A_size=a_size,seed=seed,pair_id=f'{case}:seed{seed}',schedule_len=ticks,
             adaptive_budget_total=total,fixed_matched_budget_total=sum(fixed),
             adaptive_schedule_hash=ah,fixed_matched_schedule_hash=fh,
             fixed_min=min(fixed),fixed_max=max(fixed),fixed_mean=mean(fixed),
             fixed_schedule_csv=','.join(map(str,fixed)),adaptive_schedule_csv=','.join(map(str,adaptive)),
             source_runtime_ms=source_ms,full_native_equals_adaptive_replay=int(ok),replay_diffs=diffs)
    return {'rows':rows,'schedule':rec}

def validate(rows,schedules,meta):
    errs=[]; checks=[]
    grouped=defaultdict(list)
    for r in rows: grouped[(r['case'],int(r['seed']))].append(r)
    sl={(s['case'],int(s['seed'])):s for s in schedules}
    expected=len(meta['cases'])*meta['n_seeds']
    if len(grouped)!=expected: errs.append(f'groups {len(grouped)} != {expected}')
    for key,g in sorted(grouped.items()):
        case,seed=key; cells={r['cell'] for r in g}; exp={f'{h}__{t}' for h,_ in HEAD_RULES for t in TIMING_LABELS}
        complete=(len(g)==4 and cells==exp)
        s=sl.get(key); budget=False; hashes=False; fixed_uniform=False; source_replay=False
        if s:
            B=int(s['adaptive_budget_total']); T=int(s['schedule_len'])
            budget=all(int(r['gossip_budget_pair_draws'])==B and int(r['gossip_connected_ticks'])==T for r in g)
            adapt=[r for r in g if r['timing_label']=='Adaptive']; fix=[r for r in g if r['timing_label']=='FixedMatched']
            hashes=(all(r['sync_schedule_hash']==s['adaptive_schedule_hash'] for r in adapt) and
                    all(r['sync_schedule_hash']==s['fixed_matched_schedule_hash'] for r in fix))
            fixed_uniform=(int(s['fixed_max'])-int(s['fixed_min'])<=1 and int(s['fixed_matched_budget_total'])==B)
            source_replay=bool(int(s['full_native_equals_adaptive_replay']))
        conservative=all(str(r['conservative_switching']).lower() in {'false','0'} for r in g)
        detector=all(str(r['use_quarantine']).lower() in {'true','1'} for r in g)
        c=dict(case=case,seed=seed,four_cells_complete=int(complete),equal_total_budget_all_four=int(budget),
               schedule_hashes_correct=int(hashes),fixed_matched_uniform=int(fixed_uniform),
               full_native_equals_adaptive_replay=int(source_replay),conservative_switching_off=int(conservative),
               detector_on=int(detector))
        checks.append(c)
        for k,v in c.items():
            if k not in {'case','seed'} and not int(v): errs.append(f'{case} seed={seed}: {k} failed')
    return checks,errs

def write_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def summarize(rows):
    G=defaultdict(list)
    for r in rows:G[(r['case'],r['cell'])].append(r)
    out=[]
    for (case,cell),g in sorted(G.items()):
        rec=[float(r['recovery_time_s']) for r in g if r['recovery_time_s'] not in {None,''}]
        out.append(dict(case=case,cell=cell,n_runs=len(g),final_agreement_rate=mean(float(r['success_end']) for r in g),
                        recovery_mean_s=mean(rec) if rec else float('nan'),recovery_p95_s=percentile(rec,.95) if rec else float('nan'),
                        mean_budget_pair_draws=mean(float(r['gossip_budget_pair_draws']) for r in g),
                        mean_gossip_pairs=mean(float(r['gossip_pairs']) for r in g),
                        mean_gossip_blocks_sent=mean(float(r['gossip_blocks_sent']) for r in g)))
    return out

def main():
    meta=build_meta(); out=Path(env_str('OUTDIR',str(SCRIPT_DIR/f"equal_budget_matched_{time.strftime('%Y%m%d_%H%M%S')}"))).resolve(); out.mkdir(parents=True,exist_ok=True)
    jobs=[(c,a,s,meta) for c,a in meta['cases'] for s in range(meta['seed_start'], meta['seed_start'] + meta['n_seeds'])]
    print(f"[INFO] bundles={len(jobs)} output_runs={len(jobs)*4} workers={meta['jobs_n']} out={out}")
    st=time.perf_counter()
    if meta['direct']:
        bundles=[run_bundle(j) for j in jobs]
    else:
        with Pool(meta['jobs_n']) as p: bundles=list(p.imap_unordered(run_bundle,jobs,chunksize=2))
    elapsed=time.perf_counter()-st
    rows=[r for b in bundles for r in b['rows']]; schedules=[b['schedule'] for b in bundles]
    rows.sort(key=lambda r:(r['case'],int(r['seed']),r['cell'])); schedules.sort(key=lambda s:(s['case'],int(s['seed'])))
    checks,errs=validate(rows,schedules,meta)
    write_csv(out/'raw_equal_budget_matched.csv',rows); write_csv(out/'matched_budget_schedules.csv',schedules); write_csv(out/'validation_equal_budget_matched.csv',checks); write_csv(out/'summary_equal_budget_matched.csv',summarize(rows))
    prov=[f"created={time.strftime('%Y-%m-%d %H:%M:%S %z')}",f"seed_start={meta['seed_start']}",f"n_seeds={meta['n_seeds']}",f"direct={meta['direct']}",f"cases={meta['cases']}",f"elapsed_s={elapsed:.6f}",
          f"sha256_v4={sha256(SCRIPT_DIR/'sim_context_chain_v4.py')}",f"sha256_v5={sha256(SCRIPT_DIR/'sim_context_chain_v5_factorial.py')}",f"sha256_runner={sha256(Path(__file__).resolve())}",
          "FixedMatched is an offline equal-total-budget control; it is not a deployable online controller."]
    (out/'provenance.txt').write_text('\n'.join(prov)+'\n')
    if errs:
        (out/'VALIDATION_FAILED.txt').write_text('\n'.join(errs)+'\n'); print('[FAIL]',len(errs),'errors'); print('\n'.join(errs[:20])); return 2
    (out/'VALIDATION_PASS.txt').write_text('All equal-total-budget structural checks passed.\n')
    print(f"[PASS] checks={len(checks)} elapsed={elapsed:.2f}s")
    for s in summarize(rows): print(s)
    return 0
if __name__=='__main__': raise SystemExit(main())
