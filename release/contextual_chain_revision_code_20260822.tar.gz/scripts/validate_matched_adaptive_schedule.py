#!/usr/bin/env python3
"""Validate exact matched Adaptive synchronization schedules across head rules.

For each Case x seed:
1) Run Full with native Adaptive and record the per-connected-tick low/high pair budget.
2) Replay that exact schedule into Full, HeightOnly, and BranchScoreOnly.
3) Verify native Full == replay Full operationally.
4) Verify all replayed head rules consume exactly the same schedule (hash/length/budget).

This is a smoke/definition validation, not a paper result.
"""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path
from typing import Any, Dict, Iterable

from sim_context_chain_v5_factorial import simulate

OUTDIR = Path(__file__).resolve().parent / "validation_matched_schedule_step5"
OUTDIR.mkdir(parents=True, exist_ok=True)

CASES = {"CaseA_50_50": 10, "CaseB_80_20": 16}
NSEEDS = 20

BASE = dict(
    n_nodes=20,
    block_interval_s=30.0,
    sim_time_s=3600.0,
    partition=(1200.0, 2400.0),
    epoch_len_blocks=30,
    cp_epoch_mode="height",
    cp_tiebreak="none",
    L_score_window=40,
    K_converge=30,
    use_quarantine=True,
    conservative_switching=False,
    adaptive_q_threshold=0.25,
    net_delay_mean=0.80,
    net_delay_jitter=0.20,
    net_drop_p=0.02,
    gossip_tick_s=1.0,
    gossip_pairs_normal=1,
    gossip_pairs_quarantine=4,
    block_bytes_est=250,
)

# Fields whose equality establishes that replay itself did not alter the simulation.
OPERATIONAL_FIELDS = [
    "converged_at_s", "recovery_time_s", "heads_equal_end",
    "max_reorg_depth", "max_fork_peak", "max_equivocations_total_max",
    "nodes_quarantine_end", "broadcast_blocks_sent", "broadcast_deliveries",
    "gossip_pairs", "gossip_blocks_sent", "gossip_deliveries",
    "gossip_connected_ticks", "gossip_budget_pair_draws",
    "adaptive_high_ticks", "adaptive_low_ticks",
    "broadcast_bytes_est", "gossip_bytes_est", "total_bytes_est",
]


def digest(schedule: Iterable[int]) -> str:
    return hashlib.sha256(bytes(int(x) for x in schedule)).hexdigest()


def compact_schedule(schedule: Iterable[int], low: int = 1, high: int = 4) -> str:
    # Compact reproducibility record: L/H per connected gossip tick.
    return "".join("L" if int(x) == low else "H" if int(x) == high else "?" for x in schedule)


def eq_fields(a: Dict[str, Any], b: Dict[str, Any], fields=OPERATIONAL_FIELDS):
    diffs = []
    for k in fields:
        if a.get(k) != b.get(k):
            diffs.append(f"{k}: {a.get(k)!r} != {b.get(k)!r}")
    return not diffs, " | ".join(diffs)


def main() -> int:
    rows = []
    schedules = []
    failures = []

    for case, a_size in CASES.items():
        for seed in range(NSEEDS):
            native = simulate(
                **BASE, A_size=a_size, seed=seed,
                head_rule="full", sync_policy="adaptive",
                return_sync_schedule=True,
            )
            schedule = tuple(native.pop("sync_schedule_trace"))
            expected_hash = digest(schedule)
            if native["sync_schedule_hash"] != expected_hash:
                failures.append(f"{case} seed={seed}: native schedule hash mismatch")

            replay_results = {}
            for label, rule in [
                ("Full", "full"),
                ("HeightOnly", "height_only"),
                ("BranchScoreOnly", "branch_score_only"),
            ]:
                replay_results[label] = simulate(
                    **BASE, A_size=a_size, seed=seed,
                    head_rule=rule, sync_policy="adaptive_replay",
                    sync_schedule_replay=schedule,
                )

            full_replay = replay_results["Full"]
            replay_identity, replay_diffs = eq_fields(native, full_replay)
            if not replay_identity:
                failures.append(f"{case} seed={seed}: Full native != Full replay: {replay_diffs}")

            # Full and BranchScoreOnly should remain operationally equivalent under the
            # current height-epoch/no-sticky configuration when they receive identical schedule.
            fb_identity, fb_diffs = eq_fields(full_replay, replay_results["BranchScoreOnly"])

            schedule_identical = True
            budget_identical = True
            for label, r in replay_results.items():
                schedule_identical &= (
                    r["sync_schedule_hash"] == expected_hash
                    and int(r["sync_schedule_len"]) == len(schedule)
                    and int(r["sync_schedule_replay_consumed"]) == len(schedule)
                )
                budget_identical &= int(r["gossip_budget_pair_draws"]) == sum(schedule)

                rows.append({
                    "case": case,
                    "seed": seed,
                    "head_label": label,
                    "schedule_hash": r["sync_schedule_hash"],
                    "schedule_len": r["sync_schedule_len"],
                    "replay_consumed": r["sync_schedule_replay_consumed"],
                    "budget_pair_draws": r["gossip_budget_pair_draws"],
                    "adaptive_high_ticks": r["adaptive_high_ticks"],
                    "adaptive_low_ticks": r["adaptive_low_ticks"],
                    "success_end": int(bool(r["heads_equal_end"])),
                    "recovery_time_s": r["recovery_time_s"],
                    "gossip_pairs": r["gossip_pairs"],
                    "gossip_blocks_sent": r["gossip_blocks_sent"],
                    "total_bytes_est": r["total_bytes_est"],
                })

            if not schedule_identical:
                failures.append(f"{case} seed={seed}: replay schedule not identical across head rules")
            if not budget_identical:
                failures.append(f"{case} seed={seed}: replay budget totals differ")
            if not fb_identity:
                failures.append(f"{case} seed={seed}: Full != BranchScoreOnly under matched schedule: {fb_diffs}")

            schedules.append({
                "case": case,
                "seed": seed,
                "schedule_hash": expected_hash,
                "schedule_len": len(schedule),
                "budget_pair_draws": sum(schedule),
                "high_ticks": sum(1 for x in schedule if x == 4),
                "low_ticks": sum(1 for x in schedule if x == 1),
                "schedule_LH": compact_schedule(schedule),
                "full_native_equals_full_replay": int(replay_identity),
                "full_equals_branchscore_replay": int(fb_identity),
                "all_three_schedule_identical": int(schedule_identical),
                "all_three_budget_identical": int(budget_identical),
            })

    def write(path: Path, data):
        with path.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            w.writeheader(); w.writerows(data)

    write(OUTDIR / "matched_adaptive_replay_raw.csv", rows)
    write(OUTDIR / "matched_adaptive_schedules.csv", schedules)

    n = len(schedules)
    checks = {
        "case_seed_groups": n,
        "full_native_equals_full_replay": sum(x["full_native_equals_full_replay"] for x in schedules),
        "full_equals_branchscore_replay": sum(x["full_equals_branchscore_replay"] for x in schedules),
        "all_three_schedule_identical": sum(x["all_three_schedule_identical"] for x in schedules),
        "all_three_budget_identical": sum(x["all_three_budget_identical"] for x in schedules),
        "all_use_both_low_and_high": sum(int(x["high_ticks"] > 0 and x["low_ticks"] > 0) for x in schedules),
    }
    (OUTDIR / "validation_summary.txt").write_text(
        "\n".join(f"{k}={v}" for k, v in checks.items()) + "\n"
        + f"failures={len(failures)}\n"
        + ("\n".join(failures) + "\n" if failures else "")
    )

    print("Matched Adaptive schedule validation")
    for k, v in checks.items():
        print(f"  {k}: {v}/{n}" if k != "case_seed_groups" else f"  {k}: {v}")
    print(f"  failures: {len(failures)}")
    if failures:
        for x in failures[:20]:
            print("FAIL", x)
        return 2
    print("PASS: exact Adaptive schedule replay is valid across all tested case-seed groups.")
    print(f"Saved: {OUTDIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
