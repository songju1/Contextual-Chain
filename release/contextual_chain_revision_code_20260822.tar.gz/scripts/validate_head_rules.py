#!/usr/bin/env python3
"""Step-2 validation of the three head-selection definitions.

Uses the future factorial setup's common synchronization environment:
- N=20, noisy synthetic network
- Case A (50/50) and Case B (80/20)
- fixed-high synchronization
- inconsistency detector enabled, but conservative switching disabled
- 20 matched seeds per condition

The key structural check is that, under height-based epoch labels and no cp-hash
stickiness, `full` and `branch_score_only` should be behaviorally identical.
`height_only` removes the branch-score tie-break and may differ.
"""
from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from collections import defaultdict

from sim_context_chain_v5_factorial import simulate

SCENARIOS = {"CaseA_50_50": 10, "CaseB_80_20": 16}
HEAD_RULES = ["full", "height_only", "branch_score_only"]
BASE = dict(
    n_nodes=20,
    block_interval_s=30.0,
    sim_time_s=3600.0,
    partition=(1200.0, 2400.0),
    epoch_len_blocks=30,
    cp_epoch_mode="height",
    cp_tiebreak="none",
    L_score_window=40,
    K_converge=30,
    use_quarantine=True,              # detector stays active for future adaptive arm
    conservative_switching=False,     # isolate head rule from conservative switching
    sync_policy="fixed_high",        # isolate head-rule validation first
    gossip_pairs_normal=1,
    gossip_pairs_quarantine=4,
    net_delay_mean=0.80,
    net_delay_jitter=0.20,
    net_drop_p=0.02,
    block_bytes_est=250,
)

METRICS = [
    "heads_equal_end", "recovery_time_s", "converged_at_s",
    "max_reorg_depth", "max_fork_peak", "max_equivocations_total_max",
    "nodes_quarantine_end", "broadcast_blocks_sent", "gossip_pairs",
    "gossip_blocks_sent", "total_bytes_est",
]


def run_one(task):
    scenario, a_size, rule, seed = task
    r = simulate(**BASE, A_size=a_size, head_rule=rule, seed=seed)
    row = {"scenario": scenario, "head_rule": rule, "seed": seed}
    for k in METRICS:
        row[k] = r[k]
    return row


def main():
    tasks = [
        (scenario, a_size, rule, seed)
        for scenario, a_size in SCENARIOS.items()
        for seed in range(20)
        for rule in HEAD_RULES
    ]
    with ProcessPoolExecutor(max_workers=8) as ex:
        rows = list(ex.map(run_one, tasks, chunksize=2))
    rows.sort(key=lambda x: (x["scenario"], x["seed"], x["head_rule"]))

    raw = Path("validation_head_rules_raw.csv")
    with raw.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)

    by_key = {(r["scenario"], r["seed"], r["head_rule"]): r for r in rows}
    checks = []
    for scenario in SCENARIOS:
        for seed in range(20):
            full = by_key[(scenario, seed, "full")]
            branch = by_key[(scenario, seed, "branch_score_only")]
            height = by_key[(scenario, seed, "height_only")]
            fb_diffs = [k for k in METRICS if full[k] != branch[k]]
            fh_diffs = [k for k in METRICS if full[k] != height[k]]
            checks.append({
                "scenario": scenario,
                "seed": seed,
                "full_vs_branch_identical": int(not fb_diffs),
                "full_vs_branch_diff_metrics": ";".join(fb_diffs),
                "full_vs_height_identical": int(not fh_diffs),
                "full_vs_height_diff_metrics": ";".join(fh_diffs),
            })

    chk = Path("validation_head_rules_pairs.csv")
    with chk.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=checks[0].keys())
        w.writeheader(); w.writerows(checks)

    print("Step-2 head-rule validation")
    for scenario in SCENARIOS:
        sub = [c for c in checks if c["scenario"] == scenario]
        fb = sum(c["full_vs_branch_identical"] for c in sub)
        fh = sum(c["full_vs_height_identical"] for c in sub)
        print(f"  {scenario}: Full == BranchScoreOnly in {fb}/{len(sub)} matched seeds")
        print(f"  {scenario}: Full == HeightOnly      in {fh}/{len(sub)} matched seeds")

        for rule in HEAD_RULES:
            rs = [r for r in rows if r["scenario"] == scenario and r["head_rule"] == rule]
            final = sum(int(bool(r["heads_equal_end"])) for r in rs) / len(rs)
            rec = [float(r["recovery_time_s"]) for r in rs if r["recovery_time_s"] is not None]
            mean_rec = sum(rec)/len(rec) if rec else float('nan')
            pairs = sum(float(r["gossip_pairs"]) for r in rs)/len(rs)
            print(f"    {rule:18s} final={final:.3f} mean_recovery={mean_rec:.2f}s mean_pairs={pairs:.1f}")

    all_fb = all(c["full_vs_branch_identical"] for c in checks)
    if not all_fb:
        print("WARNING: Full and BranchScoreOnly were not identical for every seed; inspect pair CSV.")
        raise SystemExit(2)
    print("PASS: Full and BranchScoreOnly are behaviorally identical under the current main checkpoint configuration.")
    print(f"Saved: {raw.resolve()}")
    print(f"Saved: {chk.resolve()}")


if __name__ == "__main__":
    main()
