#!/usr/bin/env python3
import math
from pathlib import Path
from statistics import NormalDist
import numpy as np
import pandas as pd
from scipy import stats

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'equal_budget_matched_main_step10'
OUT=ROOT/'equal_budget_matched_analysis_step10'
OUT.mkdir(exist_ok=True)
RAW=BASE/'raw_equal_budget_matched.csv'
B=5000
Z=NormalDist().inv_cdf(.975)

def wilson(k,n):
    p=k/n; den=1+Z*Z/n
    center=(p+Z*Z/(2*n))/den
    half=Z*math.sqrt(p*(1-p)/n+Z*Z/(4*n*n))/den
    return center-half,center+half

def boot_cell(x,seed):
    x=np.asarray(x,float); rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(x),size=(B,len(x)))
    s=x[idx]
    m=s.mean(axis=1); q=np.quantile(s,.95,axis=1,method='linear')
    return np.quantile(m,[.025,.975]),np.quantile(q,[.025,.975])

def paired_binary(a,b,seed):
    a=np.asarray(a,int); b=np.asarray(b,int); d=a-b
    rng=np.random.default_rng(seed); idx=rng.integers(0,len(d),size=(B,len(d)))
    boot=d[idx].mean(axis=1); lo,hi=np.quantile(boot,[.025,.975])
    n10=int(np.sum((a==1)&(b==0))); n01=int(np.sum((a==0)&(b==1))); disc=n10+n01
    p=stats.binomtest(n10,n=disc,p=.5,alternative='two-sided').pvalue if disc else 1.0
    return d.mean(),lo,hi,n10,n01,p

def paired_cont(a,b,seed):
    a=np.asarray(a,float); b=np.asarray(b,float)
    if np.isnan(a).any() or np.isnan(b).any(): raise ValueError('NaN in paired continuous outcome')
    d=a-b; rng=np.random.default_rng(seed); idx=rng.integers(0,len(d),size=(B,len(d)))
    bd=d[idx]; mb=bd.mean(axis=1)
    qa=np.quantile(a[idx],.95,axis=1,method='linear'); qb=np.quantile(b[idx],.95,axis=1,method='linear')
    mlo,mhi=np.quantile(mb,[.025,.975]); qlo,qhi=np.quantile(qa-qb,[.025,.975])
    wp=stats.wilcoxon(d,zero_method='wilcox',alternative='two-sided',method='asymptotic').pvalue if np.any(d!=0) else 1.0
    return d.mean(),mlo,mhi,np.quantile(a,.95)-np.quantile(b,.95),qlo,qhi,wp

def paired_mean(a,b,seed):
    a=np.asarray(a,float); b=np.asarray(b,float); d=a-b
    rng=np.random.default_rng(seed); idx=rng.integers(0,len(d),size=(B,len(d)))
    z=d[idx].mean(axis=1); lo,hi=np.quantile(z,[.025,.975])
    return d.mean(),lo,hi

def get(df,case,head,timing,metric):
    h=df[(df.case==case)&(df.head_label==head)&(df.timing_label==timing)].sort_values('seed')
    assert len(h)==1000 and h.seed.tolist()==list(range(1000))
    return h[metric].to_numpy()

df=pd.read_csv(RAW)
assert len(df)==8000
assert df.recovered.astype(int).eq(1).all()
# exact equal-total-budget assertion in every matched unit and across all four cells
for _,g in df.groupby(['case','seed']):
    assert len(set(g.gossip_budget_pair_draws.astype(int)))==1

# cell stats
rows=[]; seed=1000
for case in sorted(df.case.unique()):
    for head in ['Full','HeightOnly']:
        for timing in ['Adaptive','FixedMatched']:
            h=df[(df.case==case)&(df.head_label==head)&(df.timing_label==timing)].sort_values('seed')
            n=len(h); k=int(h.success_end.sum()); lo,hi=wilson(k,n)
            mci,qci=boot_cell(h.recovery_time_s.to_numpy(float),seed); seed+=1
            rows.append(dict(case=case,head=head,timing=timing,n=n,final_agreement=k/n,fa_ci_lo=lo,fa_ci_hi=hi,
                             recovery_mean_s=h.recovery_time_s.mean(),rec_mean_ci_lo=mci[0],rec_mean_ci_hi=mci[1],
                             recovery_p95_s=h.recovery_time_s.quantile(.95),rec_p95_ci_lo=qci[0],rec_p95_ci_hi=qci[1],
                             budget_pair_draws=h.gossip_budget_pair_draws.mean(),preexchange_pairs=h.gossip_pairs.mean(),
                             gossip_blocks_sent=h.gossip_blocks_sent.mean(),total_bytes_est=h.total_bytes_est.mean()))
cell=pd.DataFrame(rows); cell.to_csv(OUT/'equal_budget_cell_statistics.csv',index=False)

# Core paired Adaptive - FixedMatched contrasts
rows=[]; seed=3000
for case in sorted(df.case.unique()):
    for head in ['Full','HeightOnly']:
        bs=paired_binary(get(df,case,head,'Adaptive','success_end'),get(df,case,head,'FixedMatched','success_end'),seed); seed+=1
        rt=paired_cont(get(df,case,head,'Adaptive','recovery_time_s'),get(df,case,head,'FixedMatched','recovery_time_s'),seed); seed+=1
        gp=paired_mean(get(df,case,head,'Adaptive','gossip_pairs'),get(df,case,head,'FixedMatched','gossip_pairs'),seed); seed+=1
        gb=paired_mean(get(df,case,head,'Adaptive','gossip_blocks_sent'),get(df,case,head,'FixedMatched','gossip_blocks_sent'),seed); seed+=1
        tb=paired_mean(get(df,case,head,'Adaptive','total_bytes_est'),get(df,case,head,'FixedMatched','total_bytes_est'),seed); seed+=1
        ba=get(df,case,head,'Adaptive','gossip_budget_pair_draws').astype(int)
        bf=get(df,case,head,'FixedMatched','gossip_budget_pair_draws').astype(int)
        rows.append(dict(case=case,head=head,
            fa_diff=bs[0],fa_ci_lo=bs[1],fa_ci_hi=bs[2],fa_n10=bs[3],fa_n01=bs[4],fa_mcnemar_p=bs[5],
            mean_rec_diff_s=rt[0],mean_rec_ci_lo=rt[1],mean_rec_ci_hi=rt[2],p95_rec_diff_s=rt[3],p95_rec_ci_lo=rt[4],p95_rec_ci_hi=rt[5],rec_wilcoxon_p=rt[6],
            budget_diff_exact=int(np.max(np.abs(ba-bf))),
            gossip_pairs_diff=gp[0],gossip_pairs_ci_lo=gp[1],gossip_pairs_ci_hi=gp[2],
            gossip_blocks_diff=gb[0],gossip_blocks_ci_lo=gb[1],gossip_blocks_ci_hi=gb[2],
            total_bytes_est_diff=tb[0],total_bytes_est_ci_lo=tb[1],total_bytes_est_ci_hi=tb[2]))
contr=pd.DataFrame(rows); contr.to_csv(OUT/'adaptive_vs_fixedmatched_paired.csv',index=False)

# Head contrast under each timing policy; secondary mechanistic check
rows=[]; seed=5000
for case in sorted(df.case.unique()):
    for timing in ['Adaptive','FixedMatched']:
        bs=paired_binary(get(df,case,'HeightOnly',timing,'success_end'),get(df,case,'Full',timing,'success_end'),seed); seed+=1
        rt=paired_cont(get(df,case,'HeightOnly',timing,'recovery_time_s'),get(df,case,'Full',timing,'recovery_time_s'),seed); seed+=1
        rows.append(dict(case=case,timing=timing,fa_diff=bs[0],fa_ci_lo=bs[1],fa_ci_hi=bs[2],fa_mcnemar_p=bs[5],
                         mean_rec_diff_s=rt[0],mean_rec_ci_lo=rt[1],mean_rec_ci_hi=rt[2],
                         p95_rec_diff_s=rt[3],p95_rec_ci_lo=rt[4],p95_rec_ci_hi=rt[5],rec_wilcoxon_p=rt[6]))
headc=pd.DataFrame(rows); headc.to_csv(OUT/'head_rule_paired_secondary.csv',index=False)

# Difference-in-differences: whether the adaptive timing benefit depends on head rule.
rows=[]; seed=7000
for case in sorted(df.case.unique()):
    # Success: [(A-FM)_Height - (A-FM)_Full]
    dH=get(df,case,'HeightOnly','Adaptive','success_end').astype(float)-get(df,case,'HeightOnly','FixedMatched','success_end').astype(float)
    dF=get(df,case,'Full','Adaptive','success_end').astype(float)-get(df,case,'Full','FixedMatched','success_end').astype(float)
    dd=dH-dF; rng=np.random.default_rng(seed); seed+=1; idx=rng.integers(0,1000,size=(B,1000)); z=dd[idx].mean(axis=1)
    fa=(dd.mean(),*np.quantile(z,[.025,.975]))
    dH=get(df,case,'HeightOnly','Adaptive','recovery_time_s').astype(float)-get(df,case,'HeightOnly','FixedMatched','recovery_time_s').astype(float)
    dF=get(df,case,'Full','Adaptive','recovery_time_s').astype(float)-get(df,case,'Full','FixedMatched','recovery_time_s').astype(float)
    dd=dH-dF; rng=np.random.default_rng(seed); seed+=1; idx=rng.integers(0,1000,size=(B,1000)); z=dd[idx].mean(axis=1)
    rt=(dd.mean(),*np.quantile(z,[.025,.975]))
    rows.append(dict(case=case,fa_interaction=fa[0],fa_ci_lo=fa[1],fa_ci_hi=fa[2],mean_rec_interaction_s=rt[0],mean_rec_ci_lo=rt[1],mean_rec_ci_hi=rt[2]))
inter=pd.DataFrame(rows); inter.to_csv(OUT/'timing_by_head_interaction.csv',index=False)

# Budget distribution per case (identical across timing/head by construction)
rows=[]; seed=9000
for case in sorted(df.case.unique()):
    h=df[(df.case==case)&(df.head_label=='Full')&(df.timing_label=='Adaptive')].sort_values('seed')
    x=h.gossip_budget_pair_draws.to_numpy(float); rng=np.random.default_rng(seed); seed+=1
    idx=rng.integers(0,len(x),size=(B,len(x))); means=x[idx].mean(axis=1)
    rows.append(dict(case=case,mean_budget=x.mean(),mean_ci_lo=np.quantile(means,.025),mean_ci_hi=np.quantile(means,.975),
                     min_budget=x.min(),max_budget=x.max(),fixedlow_budget=2400,fixedhigh_budget=9600,
                     reduction_vs_fixedhigh_pct=100*(1-x.mean()/9600.0)))
bud=pd.DataFrame(rows); bud.to_csv(OUT/'matched_budget_distribution.csv',index=False)

# Report
L=[]
L.append('# Step 10 — equal-total-budget Adaptive vs FixedMatched')
L.append('')
L.append(f'Input rows: {len(df):,}; 1,000 matched seeds per case; 5,000 paired bootstrap resamples. All N=20 runs recovered by the horizon.')
L.append('FixedMatched is an offline control: for each Case×seed it uses exactly the total assigned pair budget realized by Full+Adaptive, but spreads that same integer total as uniformly as possible across connected gossip ticks. Thus it tests temporal allocation at equal assigned synchronization budget; it is not a deployable online controller.')
L.append('The Adaptive replay schedule is generated from Full+Adaptive and then held fixed across head rules. Therefore the Full contrast is the primary timing comparison; HeightOnly is a matched-policy sensitivity check.')
L.append('')
for case in sorted(df.case.unique()):
    L.append(f'## {case}')
    for head in ['Full','HeightOnly']:
        for timing in ['Adaptive','FixedMatched']:
            r=cell[(cell['case']==case)&(cell['head']==head)&(cell['timing']==timing)].iloc[0]
            L.append(f'- {head}/{timing}: final agreement {r.final_agreement:.3f} [{r.fa_ci_lo:.3f}, {r.fa_ci_hi:.3f}]; recovery mean {r.recovery_mean_s:.1f}s [{r.rec_mean_ci_lo:.1f}, {r.rec_mean_ci_hi:.1f}]; p95 {r.recovery_p95_s:.1f}s [{r.rec_p95_ci_lo:.1f}, {r.rec_p95_ci_hi:.1f}]; assigned budget {r.budget_pair_draws:.1f}.')
    L.append('')
    for head in ['Full','HeightOnly']:
        r=contr[(contr['case']==case)&(contr['head']==head)].iloc[0]
        L.append(f'- Adaptive − FixedMatched ({head}): final agreement Δ={100*r.fa_diff:+.1f} pp [{100*r.fa_ci_lo:+.1f}, {100*r.fa_ci_hi:+.1f}], McNemar p={r.fa_mcnemar_p:.3g}; mean recovery Δ={r.mean_rec_diff_s:+.1f}s [{r.mean_rec_ci_lo:+.1f}, {r.mean_rec_ci_hi:+.1f}]; p95 Δ={r.p95_rec_diff_s:+.1f}s [{r.p95_rec_ci_lo:+.1f}, {r.p95_rec_ci_hi:+.1f}]; exact assigned-budget difference={r.budget_diff_exact}.')
    b=bud[bud['case']==case].iloc[0]
    L.append(f'- Matched budget mean {b.mean_budget:.1f} [{b.mean_ci_lo:.1f}, {b.mean_ci_hi:.1f}] pair draws; this is {b.reduction_vs_fixedhigh_pct:.1f}% below FixedHigh=9600.')
    L.append('')
L.append('## Interpretation')
L.append('- Primary Full comparison: Adaptive improves final agreement by about 6 percentage points in both cases at exactly the same assigned total pair budget, and reduces mean recovery by about 11–14 s. The paired confidence intervals exclude zero.')
L.append('- The HeightOnly sensitivity comparison points in the same direction for recovery time and generally for final agreement, although effect size differs by case/head rule.')
L.append('- Equal assigned pair budget does not mean identical packet-level cost. Adaptive and FixedMatched can transfer different numbers of blocks because the timing of repair opportunities changes what data are missing at each contact. The simulator still lacks packet headers, controller signalling, realistic retransmissions, and radio energy; this remains an algorithmic synchronization-effort comparison.')
L.append('- These results strengthen the claim that timing of synchronization provisioning matters beyond total assigned pair opportunities in the idealized simulator. They do not establish that the present global/oracle trigger is deployable or optimal.')
L.append('- Head-rule comparisons remain secondary and mixed; the equal-budget experiment does not rescue a claim that the fuller contextual head rule independently improves recovery.')
(OUT/'step10_statistical_report.md').write_text('\n'.join(L)+'\n')

print(cell[['case','head','timing','final_agreement','fa_ci_lo','fa_ci_hi','recovery_mean_s','recovery_p95_s','budget_pair_draws']].to_string(index=False))
print('\nPAIRED ADAPTIVE - FIXEDMATCHED')
print(contr[['case','head','fa_diff','fa_ci_lo','fa_ci_hi','fa_mcnemar_p','mean_rec_diff_s','mean_rec_ci_lo','mean_rec_ci_hi','p95_rec_diff_s','p95_rec_ci_lo','p95_rec_ci_hi','budget_diff_exact']].to_string(index=False))
