#!/usr/bin/env python3
"""Step-3 validation of synchronization-policy separation in v5_factorial.

Purpose
-------
Verify before the 3x3 factorial experiment that synchronization policy is
operationally independent from conservative head switching.

All validation arms use:
- N=20, synthetic noisy network
- Case A (50/50) and Case B (80/20)
- height_only head rule (one fixed head rule, to isolate synchronization)
- conservative_switching=False
- 20 matched seeds

Structural checks
-----------------
1. fixed_low and fixed_high are behaviorally unchanged when the inconsistency
   detector is enabled/disabled (excluding quarantine-state diagnostics).
2. adaptive with the detector disabled is behaviorally identical to fixed_low
   with the detector disabled, because q_frac can never cross the threshold.
3. deterministic budget counters obey the exact policy identities:
      fixed_low  : budget = connected_ticks * low_pairs
      fixed_high : budget = connected_ticks * high_pairs
      adaptive   : high_ticks + low_ticks = connected_ticks, and
                   budget = high_ticks*high_pairs + low_ticks*low_pairs
4. With the detector enabled, adaptive actually enters the high-budget state
   in the tested noisy partition/rejoin scenarios; otherwise the factorial
   'adaptive' arm would collapse to fixed_low.
"""
from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from collections import defaultdict

from sim_context_chain_v5_factorial import simulate

SCENARIOS = {"CaseA_50_50": 10, "CaseB_80_20": 16}
SEEDS = range(20)
LOW = 1
HIGH = 4

BASE = dict(
    n_nodes=20,
    block_interval_s=30.0,
    sim_time_s=3600.0,
    partition=(1200.0, 2400.0),
    epoch_len_blocks=30,
    cp_epoch_mode="height",
    cp_tiebreak="none",
    L_score_window=40,
    K_converge=30,
    head_rule="height_only",
    conservative_switching=False,
    adaptive_q_threshold=0.25,
    gossip_pairs_normal=LOW,
    gossip_pairs_quarantine=HIGH,
    net_delay_mean=0.80,
    net_delay_jitter=0.20,
    net_drop_p=0.02,
    block_bytes_est=250,
)

# Conditions are deliberately redundant so we can test for hidden coupling.
CONDITIONS = {
    "fixed_low_detector_on":  dict(sync_policy="fixed_low",  use_quarantine=True),
    "fixed_low_detector_off": dict(sync_policy="fixed_low",  use_quarantine=False),
    "fixed_high_detector_on": dict(sync_policy="fixed_high", use_quarantine=True),
    "fixed_high_detector_off":dict(sync_policy="fixed_high", use_quarantine=False),
    "adaptive_detector_on":   dict(sync_policy="adaptive",   use_quarantine=True),
    "adaptive_detector_off":  dict(sync_policy="adaptive",   use_quarantine=False),
}

# Metrics that must be identical when a detector is observational only.
# Quarantine-state counters and adaptive accounting are intentionally excluded.
OP_METRICS = [
    "heads_equal_end", "recovery_time_s", "converged_at_s",
    "max_reorg_depth", "max_fork_peak", "max_equivocations_total_max",
    "broadcast_blocks_sent", "broadcast_deliveries",
    "gossip_pairs", "gossip_blocks_sent", "gossip_deliveries",
    "broadcast_bytes_est", "gossip_bytes_est", "total_bytes_est",
    "gossip_connected_ticks", "gossip_budget_pair_draws",
]

SAVE_METRICS = OP_METRICS + [
    "nodes_quarantine_end", "adaptive_high_ticks", "adaptive_low_ticks"
]


def run_one(task):
    scenario, a_size, cond_name, seed = task
    kwargs = dict(BASE)
    kwargs.update(CONDITIONS[cond_name])
    r = simulate(**kwargs, A_size=a_size, seed=seed)
    row = {
        "scenario": scenario,
        "condition": cond_name,
        "seed": seed,
        "sync_policy": kwargs["sync_policy"],
        "use_quarantine": kwargs["use_quarantine"],
        "conservative_switching": kwargs["conservative_switching"],
    }
    for k in SAVE_METRICS:
        row[k] = r[k]
    return row


def differing_metrics(a, b, metrics=OP_METRICS):
    return [k for k in metrics if a[k] != b[k]]


def check_budget_identity(row):
    ticks = int(row["gossip_connected_ticks"])
    budget = int(row["gossip_budget_pair_draws"])
    hi = int(row["adaptive_high_ticks"])
    lo = int(row["adaptive_low_ticks"])
    policy = row["sync_policy"]
    if policy == "fixed_low":
        return budget == ticks * LOW
    if policy == "fixed_high":
        return budget == ticks * HIGH
    if policy == "adaptive":
        return (hi + lo == ticks) and (budget == hi * HIGH + lo * LOW)
    return False


def main():
    tasks = [
        (scenario, a_size, cond_name, seed)
        for scenario, a_size in SCENARIOS.items()
        for seed in SEEDS
        for cond_name in CONDITIONS
    ]
    with ProcessPoolExecutor(max_workers=8) as ex:
        rows = list(ex.map(run_one, tasks, chunksize=2))
    rows.sort(key=lambda x: (x["scenario"], x["seed"], x["condition"]))

    out_dir = Path("validation_sync_policy_step3")
    out_dir.mkdir(exist_ok=True)

    raw_path = out_dir / "validation_sync_policies_raw.csv"
    with raw_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)

    by_key = {(r["scenario"], int(r["seed"]), r["condition"]): r for r in rows}
    checks = []
    failures = []

    for scenario in SCENARIOS:
        for seed in SEEDS:
            fl_on  = by_key[(scenario, seed, "fixed_low_detector_on")]
            fl_off = by_key[(scenario, seed, "fixed_low_detector_off")]
            fh_on  = by_key[(scenario, seed, "fixed_high_detector_on")]
            fh_off = by_key[(scenario, seed, "fixed_high_detector_off")]
            ad_on  = by_key[(scenario, seed, "adaptive_detector_on")]
            ad_off = by_key[(scenario, seed, "adaptive_detector_off")]

            d_fl = differing_metrics(fl_on, fl_off)
            d_fh = differing_metrics(fh_on, fh_off)
            d_adlow = differing_metrics(ad_off, fl_off)

            budget_ok = all(check_budget_identity(x) for x in [fl_on, fl_off, fh_on, fh_off, ad_on, ad_off])

            row = {
                "scenario": scenario,
                "seed": seed,
                "fixed_low_detector_independent": int(not d_fl),
                "fixed_low_diff_metrics": ";".join(d_fl),
                "fixed_high_detector_independent": int(not d_fh),
                "fixed_high_diff_metrics": ";".join(d_fh),
                "adaptive_off_equals_fixed_low_off": int(not d_adlow),
                "adaptive_off_diff_metrics": ";".join(d_adlow),
                "budget_identities_ok": int(budget_ok),
                "adaptive_on_high_ticks": int(ad_on["adaptive_high_ticks"]),
                "adaptive_on_low_ticks": int(ad_on["adaptive_low_ticks"]),
                "adaptive_on_budget": int(ad_on["gossip_budget_pair_draws"]),
                "connected_ticks": int(ad_on["gossip_connected_ticks"]),
                "adaptive_on_uses_high": int(int(ad_on["adaptive_high_ticks"]) > 0),
                "adaptive_on_uses_low": int(int(ad_on["adaptive_low_ticks"]) > 0),
            }
            checks.append(row)

            if d_fl:
                failures.append((scenario, seed, "fixed_low detector leak", d_fl))
            if d_fh:
                failures.append((scenario, seed, "fixed_high detector leak", d_fh))
            if d_adlow:
                failures.append((scenario, seed, "adaptive-off != fixed-low-off", d_adlow))
            if not budget_ok:
                failures.append((scenario, seed, "budget identity", []))

    check_path = out_dir / "validation_sync_policies_checks.csv"
    with check_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=checks[0].keys())
        w.writeheader(); w.writerows(checks)

    summary_rows = []
    print("Step-3 synchronization-policy validation")
    for scenario in SCENARIOS:
        subc = [c for c in checks if c["scenario"] == scenario]
        print(f"  {scenario}:")
        print(f"    fixed-low detector independence:  {sum(c['fixed_low_detector_independent'] for c in subc)}/{len(subc)}")
        print(f"    fixed-high detector independence: {sum(c['fixed_high_detector_independent'] for c in subc)}/{len(subc)}")
        print(f"    adaptive(detector off) == fixed-low(detector off): {sum(c['adaptive_off_equals_fixed_low_off'] for c in subc)}/{len(subc)}")
        print(f"    exact budget identities: {sum(c['budget_identities_ok'] for c in subc)}/{len(subc)}")
        print(f"    adaptive entered HIGH:   {sum(c['adaptive_on_uses_high'] for c in subc)}/{len(subc)} seeds")
        print(f"    adaptive also used LOW:  {sum(c['adaptive_on_uses_low'] for c in subc)}/{len(subc)} seeds")

        # Policy-level descriptive summary, detector ON only.
        for cond in ["fixed_low_detector_on", "fixed_high_detector_on", "adaptive_detector_on"]:
            rs = [r for r in rows if r["scenario"] == scenario and r["condition"] == cond]
            mean_budget = sum(int(r["gossip_budget_pair_draws"]) for r in rs) / len(rs)
            mean_hi = sum(int(r["adaptive_high_ticks"]) for r in rs) / len(rs)
            final = sum(int(bool(r["heads_equal_end"])) for r in rs) / len(rs)
            recs = [float(r["recovery_time_s"]) for r in rs if r["recovery_time_s"] is not None]
            mean_rec = sum(recs) / len(recs) if recs else float("nan")
            print(f"      {cond:24s} mean_budget={mean_budget:.1f}, mean_high_ticks={mean_hi:.1f}, final={final:.3f}, mean_recovery={mean_rec:.2f}s")
            summary_rows.append({
                "scenario": scenario,
                "condition": cond,
                "n_seeds": len(rs),
                "mean_budget_pair_draws": mean_budget,
                "mean_adaptive_high_ticks": mean_hi,
                "final_agreement_rate": final,
                "mean_recovery_s": mean_rec,
            })

    summary_path = out_dir / "validation_sync_policies_summary.csv"
    with summary_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=summary_rows[0].keys())
        w.writeheader(); w.writerows(summary_rows)

    if failures:
        print("FAIL: structural synchronization-policy checks failed")
        for x in failures[:20]:
            print("  ", x)
        raise SystemExit(2)

    if not all(c["adaptive_on_uses_high"] for c in checks):
        n = sum(c["adaptive_on_uses_high"] for c in checks)
        print(f"WARNING: adaptive did not enter high budget in every seed ({n}/{len(checks)} did).")
        print("This is not a structural failure, but must be considered before the factorial run.")
    else:
        print("PASS: adaptive entered the high-budget state in every matched validation seed.")

    print("PASS: synchronization policies are structurally separated from conservative head switching.")
    print(f"Saved: {raw_path.resolve()}")
    print(f"Saved: {check_path.resolve()}")
    print(f"Saved: {summary_path.resolve()}")


if __name__ == "__main__":
    main()
