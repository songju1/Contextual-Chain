#!/usr/bin/env python3
"""Verify that v5 factorial defaults reproduce v4 exactly.

Runs 2 noisy N=20 scenarios x 4 legacy variants x 10 seeds = 80 matched
conditions. Each condition is evaluated once with v4 and once with v5.
Runtime-only and v5 metadata fields are excluded from equality checks.
"""
from __future__ import annotations

import csv
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import sim_context_chain_v4 as v4
import sim_context_chain_v5_factorial as v5

SCENARIOS = {
    "CaseA_50_50": 10,
    "CaseB_80_20": 16,
}
VARIANTS = {
    "NoQ": dict(use_quarantine=False, gossip_pairs_normal=1, gossip_pairs_quarantine=1),
    "Q_only": dict(use_quarantine=True, gossip_pairs_normal=1, gossip_pairs_quarantine=1),
    "Gossip_only": dict(use_quarantine=False, gossip_pairs_normal=4, gossip_pairs_quarantine=4),
    "Both": dict(use_quarantine=True, gossip_pairs_normal=1, gossip_pairs_quarantine=4),
}
BASE = dict(
    n_nodes=20,
    block_interval_s=30.0,
    sim_time_s=3600.0,
    partition=(1200.0, 2400.0),
    epoch_len_blocks=30,
    cp_epoch_mode="height",
    cp_tiebreak="none",
    L_score_window=40,
    K_converge=30,
    net_delay_mean=0.80,
    net_delay_jitter=0.20,
    net_drop_p=0.02,
    block_bytes_est=250,
)

V5_ONLY = {"head_rule", "conservative_switching", "sync_policy", "adaptive_q_threshold"}


def run_one(task):
    scenario, a_size, variant, params, seed = task
    kwargs = {**BASE, **params, "A_size": a_size, "seed": seed}
    r4 = v4.simulate(**kwargs)
    r5 = v5.simulate(**kwargs)  # defaults must be legacy-compatible
    keys = sorted((set(r4) | set(r5)) - V5_ONLY)
    diffs = []
    for k in keys:
        if r4.get(k) != r5.get(k):
            diffs.append(f"{k}: v4={r4.get(k)!r}, v5={r5.get(k)!r}")
    return {
        "scenario": scenario,
        "variant": variant,
        "seed": seed,
        "match": int(not diffs),
        "differences": " | ".join(diffs),
        "v4_final": int(bool(r4["heads_equal_end"])),
        "v5_final": int(bool(r5["heads_equal_end"])),
        "v4_recovery": r4["recovery_time_s"],
        "v5_recovery": r5["recovery_time_s"],
    }


def main():
    tasks = []
    for scenario, a_size in SCENARIOS.items():
        for variant, params in VARIANTS.items():
            for seed in range(10):
                tasks.append((scenario, a_size, variant, params, seed))

    with ProcessPoolExecutor(max_workers=8) as ex:
        rows = list(ex.map(run_one, tasks, chunksize=2))

    rows.sort(key=lambda x: (x["scenario"], x["variant"], x["seed"]))
    out = Path("validation_v4_vs_v5.csv")
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)

    passed = sum(r["match"] for r in rows)
    print(f"Compatibility: {passed}/{len(rows)} matched conditions")
    if passed != len(rows):
        for r in rows:
            if not r["match"]:
                print("MISMATCH", r)
        raise SystemExit(1)
    print("PASS: v5 legacy defaults reproduce v4 for all tested conditions.")
    print(f"Saved: {out.resolve()}")


if __name__ == "__main__":
    main()
