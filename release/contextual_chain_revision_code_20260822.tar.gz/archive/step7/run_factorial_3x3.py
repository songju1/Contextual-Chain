#!/usr/bin/env python3
"""Run the matched-schedule 3x3 attribution factorial for Contextual Chain.

Core factorial
--------------
Head-selection factor (3 levels):
    Full            -> v4 ordering (epoch-labelled height + branch-score tie)
    HeightOnly      -> height + deterministic block-id tie
    BranchScoreOnly -> height + branch-score tie, with no epoch-level ordering

Synchronization factor (3 levels):
    FixedLow  -> 1 gossip-pair draw per connected gossip tick
    FixedHigh -> 4 gossip-pair draws per connected gossip tick
    Adaptive  -> EXACT replay of one Full-generated low/high schedule per Case x seed

For all nine factorial cells:
    - inconsistency detection is ON (use_quarantine=True),
    - conservative head switching is OFF,
    - Adaptive schedule is generated once from Full + native Adaptive for that Case x seed,
      then replayed identically into Full, HeightOnly, and BranchScoreOnly.

This design directly addresses the attribution question: within each Case x seed, the
three head rules receive an identical synchronization schedule in the Adaptive column.
The schedule-source run is NOT included as a factorial observation.  A replayed Full
run is included, and is checked against the source run for exact operational identity.

An optional LegacyBoth reference reproduces the original coupled setting
(Full + conservative switching + legacy 1->4 oracle-assisted adaptive gossip), but is
NOT included in factorial-effect calculations.

Environment variables
---------------------
NSEEDS                   default 1000 (5 when SMOKE=1 and NSEEDS is unset)
JOBS                     default min(cpu_count, 5)
NET                       noisy|clean, default noisy
EXTRA_CASES               default "CaseA_50_50 CaseB_80_20"
OUTDIR                    output directory; default timestamped factorial_3x3_...
INCLUDE_LEGACY_REFERENCE  1|0, default 1
SMOKE                     1|0

The same integer seed labels are used for every cell within each case.  Policy choices
can consume different pseudo-random variates after trajectories diverge, so fixed-policy
comparisons are matched-seed comparisons rather than guaranteed lock-step CRN streams.
The Adaptive synchronization SCHEDULE itself, however, is exactly identical across the
three head-rule cells for every Case x seed and is recorded with a SHA-256 hash.
"""
from __future__ import annotations

import csv
import hashlib
import math
import os
import platform
import sys
import time
from collections import defaultdict
from multiprocessing import Pool
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Sequence, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from sim_context_chain_v5_factorial import simulate  # type: ignore

HEAD_RULES: List[Tuple[str, str]] = [
    ("Full", "full"),
    ("HeightOnly", "height_only"),
    ("BranchScoreOnly", "branch_score_only"),
]
SYNC_LABELS = ["FixedLow", "FixedHigh", "Adaptive"]

# Equality fields used to verify that schedule replay itself does not alter Full.
REPLAY_IDENTITY_FIELDS = [
    "converged_at_s", "recovery_time_s", "heads_equal_end",
    "max_reorg_depth", "max_fork_peak", "max_equivocations_total_max",
    "nodes_quarantine_end", "broadcast_blocks_sent", "broadcast_deliveries",
    "gossip_pairs", "gossip_blocks_sent", "gossip_deliveries",
    "gossip_connected_ticks", "gossip_budget_pair_draws",
    "adaptive_high_ticks", "adaptive_low_ticks",
    "broadcast_bytes_est", "gossip_bytes_est", "total_bytes_est",
]


def env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    return default if raw is None or raw == "" else int(raw)


def env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    return default if raw is None or raw == "" else float(raw)


def env_str(name: str, default: str) -> str:
    raw = os.getenv(name)
    return default if raw is None or raw == "" else raw


def env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def parse_cases(raw: str, n_nodes: int) -> List[Tuple[str, int]]:
    cases: List[Tuple[str, int]] = []
    seen = set()
    for tok in raw.replace(",", " ").split():
        low = tok.strip().lower()
        if not low:
            continue
        if low in {"casea", "casea_50_50", "50_50", "50/50"}:
            item = ("CaseA_50_50", n_nodes // 2)
        elif low in {"caseb", "caseb_80_20", "80_20", "80/20"}:
            item = ("CaseB_80_20", int(round(0.8 * n_nodes)))
        else:
            raise ValueError(f"Unsupported case token: {tok}")
        if item[0] not in seen:
            cases.append(item)
            seen.add(item[0])
    if not cases:
        raise ValueError("No cases selected")
    return cases


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def digest_schedule(schedule: Sequence[int]) -> str:
    return hashlib.sha256(bytes(int(x) for x in schedule)).hexdigest()


def compact_schedule(schedule: Sequence[int], low: int, high: int) -> str:
    return "".join("L" if int(x) == low else "H" if int(x) == high else "?" for x in schedule)


def percentile(values: Iterable[float], p: float) -> float:
    xs = sorted(float(v) for v in values)
    if not xs:
        return float("nan")
    if len(xs) == 1:
        return xs[0]
    pos = (len(xs) - 1) * p
    lo, hi = math.floor(pos), math.ceil(pos)
    if lo == hi:
        return xs[lo]
    frac = pos - lo
    return xs[lo] * (1 - frac) + xs[hi] * frac


def build_meta() -> Dict[str, Any]:
    smoke = env_bool("SMOKE", False)
    if os.getenv("NSEEDS") in {None, ""}:
        n_seeds = 5 if smoke else 1000
    else:
        n_seeds = env_int("NSEEDS", 1000)

    n_nodes = env_int("N_NODES", 20)
    jobs_n = env_int("JOBS", min(max(1, os.cpu_count() or 1), 5))
    include_legacy = env_bool("INCLUDE_LEGACY_REFERENCE", True)
    cases = parse_cases(env_str("EXTRA_CASES", "CaseA_50_50 CaseB_80_20"), n_nodes)

    net_mode = env_str("NET", "noisy").lower()
    if net_mode == "noisy":
        delay_mean = env_float("NET_DELAY_MEAN", 0.80)
        delay_jitter = env_float("NET_DELAY_JITTER", 0.20)
        drop_p = env_float("NET_DROP_P", 0.02)
    elif net_mode == "clean":
        delay_mean = env_float("NET_DELAY_MEAN", 0.25)
        delay_jitter = env_float("NET_DELAY_JITTER", 0.10)
        drop_p = env_float("NET_DROP_P", 0.0)
    else:
        raise ValueError(f"Unsupported NET={net_mode}")

    common = dict(
        n_nodes=n_nodes,
        block_interval_s=env_float("BLOCK_INTERVAL_S", 30.0),
        sim_time_s=env_float("SIM_TIME_S", 3600.0),
        partition=(env_float("PARTITION_START_S", 1200.0), env_float("PARTITION_END_S", 2400.0)),
        epoch_len_blocks=env_int("EPOCH_LEN_BLOCKS", 30),
        cp_epoch_mode=env_str("CP_EPOCH_MODE", "height"),
        cp_tiebreak=env_str("CP_TIEBREAK", "none"),
        L_score_window=env_int("L_SCORE_WINDOW", 40),
        K_converge=env_int("K_CONVERGE", 30),
        use_quarantine=True,
        conservative_switching=False,
        adaptive_q_threshold=env_float("ADAPTIVE_Q_THRESHOLD", 0.25),
        net_delay_mean=delay_mean,
        net_delay_jitter=delay_jitter,
        net_drop_p=drop_p,
        gossip_tick_s=env_float("GOSSIP_TICK_S", 1.0),
        gossip_pairs_normal=env_int("GOSSIP_PAIRS_LOW", 1),
        gossip_pairs_quarantine=env_int("GOSSIP_PAIRS_HIGH", 4),
        block_bytes_est=env_int("BLOCK_BYTES_EST", 250),
    )

    return dict(
        smoke=smoke,
        n_seeds=n_seeds,
        jobs_n=jobs_n,
        include_legacy_reference=include_legacy,
        cases=cases,
        net_mode=net_mode,
        factorial_cells=[f"{h[0]}__{s}" for h in HEAD_RULES for s in SYNC_LABELS],
        **common,
    )


def sim_kwargs(common: Dict[str, Any], *, a_size: int, seed: int, head_rule: str,
               sync_policy: str, conservative_switching: Any = False,
               sync_schedule_replay: Sequence[int] | None = None,
               return_sync_schedule: bool = False) -> Dict[str, Any]:
    keys = [
        "n_nodes", "block_interval_s", "sim_time_s", "partition", "epoch_len_blocks",
        "cp_epoch_mode", "cp_tiebreak", "L_score_window", "K_converge",
        "use_quarantine", "adaptive_q_threshold", "net_delay_mean", "net_delay_jitter",
        "net_drop_p", "gossip_tick_s", "gossip_pairs_normal",
        "gossip_pairs_quarantine", "block_bytes_est",
    ]
    d = {k: common[k] for k in keys}
    d.update(
        A_size=a_size,
        seed=seed,
        head_rule=head_rule,
        conservative_switching=conservative_switching,
        sync_policy=sync_policy,
        sync_schedule_replay=sync_schedule_replay,
        return_sync_schedule=return_sync_schedule,
    )
    return d


def make_row(case: str, a_size: int, seed: int, head_label: str, sync_label: str,
             is_factorial: int, common: Dict[str, Any], result: Dict[str, Any],
             runtime_ms: float, schedule_source_hash: str = "") -> Dict[str, Any]:
    row = {
        "case": case,
        "A_size": a_size,
        "seed": seed,
        "pair_id": f"{case}:seed{seed}",
        "is_factorial": is_factorial,
        "head_label": head_label,
        "sync_label": sync_label,
        "cell": f"{head_label}__{sync_label}" if is_factorial else "Full__LegacyBoth_reference",
        "n_nodes": common["n_nodes"],
        "block_interval_s": common["block_interval_s"],
        "sim_time_s": common["sim_time_s"],
        "partition_start_s": common["partition"][0],
        "partition_end_s": common["partition"][1],
        "epoch_len_blocks": common["epoch_len_blocks"],
        "L_score_window": common["L_score_window"],
        "K_converge": common["K_converge"],
        "net_delay_mean": common["net_delay_mean"],
        "net_delay_jitter": common["net_delay_jitter"],
        "net_drop_p": common["net_drop_p"],
        "gossip_tick_s": common["gossip_tick_s"],
        "gossip_pairs_low": common["gossip_pairs_normal"],
        "gossip_pairs_high": common["gossip_pairs_quarantine"],
        "adaptive_schedule_source_hash": schedule_source_hash,
        "runtime_ms": runtime_ms,
        "success_end": int(bool(result["heads_equal_end"])),
        "recovered": int(result["recovery_time_s"] is not None),
    }
    row.update(result)
    return row


def operational_equal(a: Dict[str, Any], b: Dict[str, Any]) -> Tuple[bool, str]:
    diffs = []
    for k in REPLAY_IDENTITY_FIELDS:
        if a.get(k) != b.get(k):
            diffs.append(f"{k}: {a.get(k)!r} != {b.get(k)!r}")
    return (not diffs), " | ".join(diffs)


def run_case_seed_bundle(task: Dict[str, Any]) -> Dict[str, Any]:
    """Run one matched Case x seed bundle and return its 9 (+reference) rows."""
    case = str(task["case"])
    a_size = int(task["A_size"])
    seed = int(task["seed"])
    common = task["common"]
    include_legacy = bool(task["include_legacy"])

    # 1) Generate one canonical Adaptive schedule from Full with conservative switching OFF.
    t0 = time.perf_counter()
    source = simulate(**sim_kwargs(
        common, a_size=a_size, seed=seed, head_rule="full", sync_policy="adaptive",
        conservative_switching=False, return_sync_schedule=True,
    ))
    source_runtime_ms = (time.perf_counter() - t0) * 1000.0
    schedule = tuple(int(x) for x in source.pop("sync_schedule_trace"))
    schedule_hash = digest_schedule(schedule)
    if source.get("sync_schedule_hash") != schedule_hash:
        raise RuntimeError(f"{case} seed={seed}: source schedule hash mismatch")

    rows: List[Dict[str, Any]] = []
    replay_full_result: Dict[str, Any] | None = None

    # 2) Run the exact 3x3 factorial. Adaptive is replayed identically for all head rules.
    for head_label, head_rule in HEAD_RULES:
        for sync_label in SYNC_LABELS:
            if sync_label == "FixedLow":
                policy = "fixed_low"
                replay = None
            elif sync_label == "FixedHigh":
                policy = "fixed_high"
                replay = None
            else:
                policy = "adaptive_replay"
                replay = schedule

            rt0 = time.perf_counter()
            result = simulate(**sim_kwargs(
                common, a_size=a_size, seed=seed, head_rule=head_rule,
                sync_policy=policy, conservative_switching=False,
                sync_schedule_replay=replay,
            ))
            runtime_ms = (time.perf_counter() - rt0) * 1000.0
            if head_label == "Full" and sync_label == "Adaptive":
                replay_full_result = result
            rows.append(make_row(
                case, a_size, seed, head_label, sync_label, 1, common, result,
                runtime_ms, schedule_source_hash=schedule_hash if sync_label == "Adaptive" else "",
            ))

    # 3) Optional original coupled Both reference, not part of factorial.
    if include_legacy:
        rt0 = time.perf_counter()
        legacy = simulate(**sim_kwargs(
            common, a_size=a_size, seed=seed, head_rule="full", sync_policy="legacy",
            conservative_switching=None,
        ))
        rows.append(make_row(
            case, a_size, seed, "Full", "LegacyBoth", 0, common, legacy,
            (time.perf_counter() - rt0) * 1000.0,
        ))

    if replay_full_result is None:
        raise RuntimeError("Internal error: replay Full Adaptive result missing")
    replay_identity, replay_diffs = operational_equal(source, replay_full_result)

    low = int(common["gossip_pairs_normal"])
    high = int(common["gossip_pairs_quarantine"])
    schedule_record = {
        "case": case,
        "A_size": a_size,
        "seed": seed,
        "pair_id": f"{case}:seed{seed}",
        "schedule_source": "Full_native_Adaptive_conservativeOFF",
        "schedule_hash": schedule_hash,
        "schedule_len": len(schedule),
        "budget_pair_draws": sum(schedule),
        "high_ticks": sum(1 for x in schedule if x == high),
        "low_ticks": sum(1 for x in schedule if x == low),
        "schedule_LH": compact_schedule(schedule, low, high),
        "source_runtime_ms": source_runtime_ms,
        "full_native_equals_full_replay": int(replay_identity),
        "full_native_vs_replay_diffs": replay_diffs,
    }
    return {"rows": rows, "schedule": schedule_record}


def summarize(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        groups[(str(r["case"]), str(r["cell"]))].append(r)

    output: List[Dict[str, Any]] = []
    for (case, cell), grp in sorted(groups.items()):
        rec = [float(r["recovery_time_s"]) for r in grp if r["recovery_time_s"] not in {None, ""}]
        output.append({
            "case": case,
            "cell": cell,
            "is_factorial": grp[0]["is_factorial"],
            "head_label": grp[0]["head_label"],
            "sync_label": grp[0]["sync_label"],
            "n_runs": len(grp),
            "final_agreement_rate": mean(float(r["success_end"]) for r in grp),
            "recovery_by_horizon_rate": mean(float(r["recovered"]) for r in grp),
            "recovery_mean_s": mean(rec) if rec else float("nan"),
            "recovery_p95_s": percentile(rec, 0.95) if rec else float("nan"),
            "mean_budget_pair_draws": mean(float(r["gossip_budget_pair_draws"]) for r in grp),
            "mean_preexchange_surviving_pairs": mean(float(r["gossip_pairs"]) for r in grp),
            "mean_gossip_blocks_sent": mean(float(r["gossip_blocks_sent"]) for r in grp),
            "mean_total_bytes_proxy": mean(float(r["total_bytes_est"]) for r in grp),
            "mean_adaptive_high_ticks": mean(float(r["adaptive_high_ticks"]) for r in grp),
            "mean_adaptive_low_ticks": mean(float(r["adaptive_low_ticks"]) for r in grp),
            "runtime_mean_ms": mean(float(r["runtime_ms"]) for r in grp),
        })
    return output


def validate_structure(rows: List[Dict[str, Any]], schedules: List[Dict[str, Any]],
                       meta: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Validate factorial completeness, budgets, and exact Adaptive schedule matching."""
    errors: List[str] = []
    checks: List[Dict[str, Any]] = []
    factorial_rows = [r for r in rows if int(r["is_factorial"]) == 1]
    expected_cells = set(meta["factorial_cells"])
    low = int(meta["gossip_pairs_normal"])
    high = int(meta["gossip_pairs_quarantine"])
    sched_lookup = {(str(s["case"]), int(s["seed"])): s for s in schedules}

    grouped: Dict[Tuple[str, int], List[Dict[str, Any]]] = defaultdict(list)
    for r in factorial_rows:
        grouped[(str(r["case"]), int(r["seed"]))].append(r)

    expected_pairs = len(meta["cases"]) * int(meta["n_seeds"])
    if len(grouped) != expected_pairs:
        errors.append(f"Expected {expected_pairs} case-seed groups, found {len(grouped)}")
    if len(schedules) != expected_pairs:
        errors.append(f"Expected {expected_pairs} schedule records, found {len(schedules)}")

    compare_metrics = [
        "success_end", "recovery_time_s", "converged_at_s", "max_reorg_depth",
        "max_fork_peak", "broadcast_blocks_sent", "gossip_pairs",
        "gossip_blocks_sent", "gossip_budget_pair_draws", "total_bytes_est",
    ]

    for (case, seed), grp in sorted(grouped.items()):
        cells = {str(r["cell"]) for r in grp}
        complete = cells == expected_cells and len(grp) == 9
        if not complete:
            errors.append(f"{case} seed={seed}: incomplete/duplicate cells ({len(grp)} rows, {len(cells)} unique)")

        budget_ok = True
        conservative_off = True
        detector_on = True
        adaptive_rows = []
        for r in grp:
            ticks = int(r["gossip_connected_ticks"])
            budget = int(r["gossip_budget_pair_draws"])
            policy = str(r["sync_policy"])
            conservative_off &= (str(r["conservative_switching"]).lower() in {"false", "0"} or r["conservative_switching"] is False)
            detector_on &= (str(r["use_quarantine"]).lower() in {"true", "1"} or r["use_quarantine"] is True)
            if str(r["sync_label"]) == "FixedLow":
                budget_ok &= policy == "fixed_low" and budget == ticks * low
            elif str(r["sync_label"]) == "FixedHigh":
                budget_ok &= policy == "fixed_high" and budget == ticks * high
            elif str(r["sync_label"]) == "Adaptive":
                adaptive_rows.append(r)
                hi_ticks = int(r["adaptive_high_ticks"])
                lo_ticks = int(r["adaptive_low_ticks"])
                budget_ok &= policy == "adaptive_replay"
                budget_ok &= hi_ticks + lo_ticks == ticks
                budget_ok &= budget == hi_ticks * high + lo_ticks * low
            else:
                budget_ok = False

        sched = sched_lookup.get((case, seed))
        adaptive_schedule_identical = False
        adaptive_budget_identical = False
        adaptive_uses_both = False
        full_native_equals_replay = False
        if sched is None:
            errors.append(f"{case} seed={seed}: missing schedule record")
        elif len(adaptive_rows) == 3:
            expected_hash = str(sched["schedule_hash"])
            expected_len = int(sched["schedule_len"])
            expected_budget = int(sched["budget_pair_draws"])
            adaptive_schedule_identical = all(
                str(r["sync_schedule_hash"]) == expected_hash
                and str(r["adaptive_schedule_source_hash"]) == expected_hash
                and int(r["sync_schedule_len"]) == expected_len
                and int(r["sync_schedule_replay_consumed"]) == expected_len
                for r in adaptive_rows
            )
            adaptive_budget_identical = all(int(r["gossip_budget_pair_draws"]) == expected_budget for r in adaptive_rows)
            adaptive_uses_both = int(sched["high_ticks"]) > 0 and int(sched["low_ticks"]) > 0
            full_native_equals_replay = bool(int(sched["full_native_equals_full_replay"]))
        else:
            errors.append(f"{case} seed={seed}: expected 3 Adaptive rows, got {len(adaptive_rows)}")

        lookup = {(str(r["head_label"]), str(r["sync_label"])): r for r in grp}
        full_branch_equal_cells = 0
        for sync_label in SYNC_LABELS:
            a = lookup.get(("Full", sync_label))
            b = lookup.get(("BranchScoreOnly", sync_label))
            if a is not None and b is not None and all(a[k] == b[k] for k in compare_metrics):
                full_branch_equal_cells += 1

        checks.append({
            "case": case,
            "seed": seed,
            "nine_cells_complete": int(complete),
            "budget_identities_ok": int(budget_ok),
            "all_factorial_conservative_switching_off": int(conservative_off),
            "all_factorial_detector_on": int(detector_on),
            "adaptive_schedule_identical_all_three": int(adaptive_schedule_identical),
            "adaptive_budget_identical_all_three": int(adaptive_budget_identical),
            "adaptive_source_uses_low_and_high": int(adaptive_uses_both),
            "full_native_equals_full_replay": int(full_native_equals_replay),
            "full_equals_branchscore_cells_out_of_3": full_branch_equal_cells,
        })

        if not budget_ok:
            errors.append(f"{case} seed={seed}: budget identity failed")
        if not conservative_off:
            errors.append(f"{case} seed={seed}: conservative switching leaked into factorial")
        if not detector_on:
            errors.append(f"{case} seed={seed}: detector disabled in a factorial cell")
        if not adaptive_schedule_identical:
            errors.append(f"{case} seed={seed}: Adaptive schedule differs across head rules/source")
        if not adaptive_budget_identical:
            errors.append(f"{case} seed={seed}: Adaptive total budget differs across head rules")
        if not adaptive_uses_both:
            errors.append(f"{case} seed={seed}: Adaptive source did not use both low and high budgets")
        if not full_native_equals_replay:
            errors.append(f"{case} seed={seed}: Full native Adaptive != Full replay")

    return checks, errors


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"No rows for {path}")
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_provenance(outdir: Path, meta: Dict[str, Any], n_rows: int,
                     n_schedule_sources: int, elapsed_s: float) -> None:
    v4 = SCRIPT_DIR / "sim_context_chain_v4.py"
    v5 = SCRIPT_DIR / "sim_context_chain_v5_factorial.py"
    runner = Path(__file__).resolve()
    lines = [
        "Contextual Chain matched-schedule 3x3 factorial attribution experiment",
        f"created_local={time.strftime('%Y-%m-%d %H:%M:%S %z')}",
        f"python={sys.version.replace(chr(10), ' ')}",
        f"platform={platform.platform()}",
        f"command={' '.join(sys.argv)}",
        f"n_output_rows={n_rows}",
        f"n_adaptive_schedule_source_runs={n_schedule_sources}",
        f"elapsed_s={elapsed_s:.6f}",
        f"n_seeds={meta['n_seeds']}",
        f"cases={meta['cases']}",
        f"factorial_cells={meta['factorial_cells']}",
        f"include_legacy_reference={meta['include_legacy_reference']}",
        f"network_mode={meta['net_mode']}",
        f"n_nodes={meta['n_nodes']}",
        f"partition={meta['partition']}",
        f"epoch_len_blocks={meta['epoch_len_blocks']}",
        f"cp_epoch_mode={meta['cp_epoch_mode']}",
        f"cp_tiebreak={meta['cp_tiebreak']}",
        f"conservative_switching_factorial={meta['conservative_switching']}",
        f"detector_factorial_use_quarantine={meta['use_quarantine']}",
        f"adaptive_q_threshold={meta['adaptive_q_threshold']}",
        f"gossip_pairs_low={meta['gossip_pairs_normal']}",
        f"gossip_pairs_high={meta['gossip_pairs_quarantine']}",
        f"net_delay_mean={meta['net_delay_mean']}",
        f"net_delay_jitter={meta['net_delay_jitter']}",
        f"net_drop_p={meta['net_drop_p']}",
        "adaptive_schedule_source=Full + native Adaptive + conservative switching OFF",
        "adaptive_factorial_policy=exact replay of the source schedule in all 3 head rules",
        "",
        f"sha256_sim_context_chain_v4.py={sha256(v4)}",
        f"sha256_sim_context_chain_v5_factorial.py={sha256(v5)}",
        f"sha256_run_factorial_3x3.py={sha256(runner)}",
        "",
        "NOTE: The Adaptive low/high schedule is exactly matched across head rules within",
        "each Case x seed. Equal seed labels are also used across all cells, but after head",
        "trajectories diverge, pseudo-random call streams need not remain lock-step.",
    ]
    (outdir / "provenance.txt").write_text("\n".join(lines) + "\n")


def main() -> int:
    meta = build_meta()
    default_name = f"factorial_3x3_{time.strftime('%Y%m%d_%H%M%S')}"
    outdir = Path(env_str("OUTDIR", str(SCRIPT_DIR / default_name))).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    tasks = [
        {
            "case": case_label,
            "A_size": a_size,
            "seed": seed,
            "common": meta,
            "include_legacy": meta["include_legacy_reference"],
        }
        for case_label, a_size in meta["cases"]
        for seed in range(int(meta["n_seeds"]))
    ]
    output_rows_per_bundle = 9 + (1 if meta["include_legacy_reference"] else 0)
    source_runs = len(tasks)

    print("[INFO] Contextual Chain matched-schedule 3x3 factorial")
    print(f"[INFO] outdir={outdir}")
    print(f"[INFO] smoke={meta['smoke']} n_seeds={meta['n_seeds']} workers={meta['jobs_n']}")
    print(f"[INFO] cases={meta['cases']}")
    print(f"[INFO] factorial cells=9; legacy reference={meta['include_legacy_reference']}")
    print(f"[INFO] case-seed bundles={len(tasks)}")
    print(f"[INFO] output runs={len(tasks) * output_rows_per_bundle}; additional schedule-source runs={source_runs}")

    start = time.perf_counter()
    with Pool(processes=int(meta["jobs_n"])) as pool:
        bundles = list(pool.imap_unordered(run_case_seed_bundle, tasks, chunksize=1))
    elapsed = time.perf_counter() - start

    rows = [r for bundle in bundles for r in bundle["rows"]]
    schedules = [bundle["schedule"] for bundle in bundles]
    rows.sort(key=lambda r: (str(r["case"]), int(r["seed"]), int(r["is_factorial"]) * -1, str(r["cell"])))
    schedules.sort(key=lambda s: (str(s["case"]), int(s["seed"])))

    checks, errors = validate_structure(rows, schedules, meta)
    summary = summarize(rows)

    write_csv(outdir / "raw_factorial_3x3.csv", rows)
    write_csv(outdir / "matched_adaptive_schedules.csv", schedules)
    write_csv(outdir / "summary_factorial_3x3.csv", summary)
    write_csv(outdir / "validation_factorial_structure.csv", checks)
    write_provenance(outdir, meta, len(rows), source_runs, elapsed)

    print(f"[INFO] elapsed={elapsed:.2f}s")
    print(f"[INFO] structure groups={len(checks)} errors={len(errors)}")

    for case_label, _ in meta["cases"]:
        case_checks = [x for x in checks if x["case"] == case_label]
        print(f"[CHECK] {case_label}: {len(case_checks)} matched seeds")
        for field in [
            "nine_cells_complete", "budget_identities_ok",
            "all_factorial_conservative_switching_off", "all_factorial_detector_on",
            "adaptive_schedule_identical_all_three", "adaptive_budget_identical_all_three",
            "adaptive_source_uses_low_and_high", "full_native_equals_full_replay",
        ]:
            print(f"        {field}: {sum(int(x[field]) for x in case_checks)}/{len(case_checks)}")
        print("        Full==BranchScoreOnly cell count distribution:",
              {k: sum(1 for x in case_checks if int(x['full_equals_branchscore_cells_out_of_3']) == k) for k in range(4)})

    print("\n[SMOKE SUMMARY / DESCRIPTIVE ONLY]" if meta["smoke"] else "\n[SUMMARY]")
    for s in summary:
        print(
            f"{s['case']:14s} {s['cell']:34s} n={s['n_runs']:4d} "
            f"final={s['final_agreement_rate']:.3f} rec_mean={s['recovery_mean_s']:.2f}s "
            f"budget={s['mean_budget_pair_draws']:.1f}"
        )

    if errors:
        (outdir / "VALIDATION_FAILED.txt").write_text("\n".join(errors) + "\n")
        print("[FAIL] Structural validation failed. See VALIDATION_FAILED.txt")
        for e in errors[:20]:
            print("  -", e)
        return 2

    (outdir / "VALIDATION_PASS.txt").write_text(
        "All matched-schedule factorial structural and budget-accounting checks passed.\n"
    )
    print("[PASS] Matched-schedule factorial structural validation passed")
    print(f"[SAVED] {outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
