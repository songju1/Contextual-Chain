#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, sys
from pathlib import Path
from typing import Sequence, Tuple

HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))
from sim_context_chain_v6_crn import simulate


def balanced_uniform_schedule(total:int,ticks:int)->Tuple[int,...]:
    base,rem=divmod(total,ticks)
    out=[]; prev=0
    for i in range(ticks):
        cur=((i+1)*rem)//ticks
        out.append(base+(cur-prev)); prev=cur
    assert len(out)==ticks and sum(out)==total
    return tuple(out)

COMMON=dict(
    n_nodes=20,block_interval_s=30.0,sim_time_s=3600.0,partition=(1200.0,2400.0),
    epoch_len_blocks=30,cp_epoch_mode='height',cp_tiebreak='none',L_score_window=40,
    K_converge=30,use_quarantine=True,conservative_switching=False,adaptive_q_threshold=.25,
    net_delay_mean=.80,net_delay_jitter=.20,net_drop_p=.02,gossip_tick_s=1.0,
    gossip_pairs_normal=1,gossip_pairs_quarantine=4,block_bytes_est=250,
    head_rule='full',return_trace_hashes=True,
)
IDENTITY_FIELDS=[
    'converged_at_s','recovery_time_s','heads_equal_end','max_reorg_depth','max_fork_peak',
    'gossip_pairs','gossip_blocks_sent','gossip_budget_pair_draws','sync_schedule_hash'
]

def one(case:str,A_size:int,seed:int):
    src=simulate(**COMMON,A_size=A_size,seed=seed,sync_policy='adaptive',return_sync_schedule=True)
    adaptive=tuple(src['sync_schedule_trace'])
    fixed=balanced_uniform_schedule(sum(adaptive),len(adaptive))
    replay=simulate(**COMMON,A_size=A_size,seed=seed,sync_policy='adaptive_replay',sync_schedule_replay=adaptive)
    fix=simulate(**COMMON,A_size=A_size,seed=seed,sync_policy='fixed_matched_replay',sync_schedule_replay=fixed)

    replay_identity=all(src.get(k)==replay.get(k) for k in IDENTITY_FIELDS)
    proposal_match=(src['proposal_trace_hash']==replay['proposal_trace_hash']==fix['proposal_trace_hash'])
    broadcast_match=(src['broadcast_trace_hash']==replay['broadcast_trace_hash']==fix['broadcast_trace_hash'])
    gossip_match=(src['gossip_opportunity_trace_hash']==replay['gossip_opportunity_trace_hash']==fix['gossip_opportunity_trace_hash'])
    budget_match=(src['gossip_budget_pair_draws']==replay['gossip_budget_pair_draws']==fix['gossip_budget_pair_draws'])
    opp_match=(src['gossip_opportunities_total']==replay['gossip_opportunities_total']==fix['gossip_opportunities_total'])
    return dict(case=case,A_size=A_size,seed=seed,budget=src['gossip_budget_pair_draws'],
                native_equals_adaptive_replay=int(replay_identity),proposal_trace_match=int(proposal_match),
                broadcast_trace_match=int(broadcast_match),gossip_opportunity_trace_match=int(gossip_match),
                equal_budget=int(budget_match),equal_opportunity_count=int(opp_match),
                adaptive_final=int(src['heads_equal_end']),fixed_final=int(fix['heads_equal_end']),
                adaptive_recovery=src['recovery_time_s'],fixed_recovery=fix['recovery_time_s'])

def main():
    rows=[]
    for case,a in [('CaseA_50_50',10),('CaseB_80_20',16)]:
        for seed in range(10):
            r=one(case,a,seed); rows.append(r); print(r)
    out=HERE/'validation_crn_smoke.csv'
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    checks=['native_equals_adaptive_replay','proposal_trace_match','broadcast_trace_match','gossip_opportunity_trace_match','equal_budget','equal_opportunity_count']
    bad=[r for r in rows if not all(int(r[k]) for k in checks)]
    if bad:
        print(f'FAIL: {len(bad)} rows',file=sys.stderr); return 2
    print(f'PASS: {len(rows)} Case×seed bundles; all CRN structural checks passed. CSV={out}')
    return 0

if __name__=='__main__': raise SystemExit(main())
