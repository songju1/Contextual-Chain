#!/usr/bin/env python3
from __future__ import annotations
import math, csv
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.stats import binomtest

HERE=Path(__file__).resolve().parent
OUT=HERE/'equal_budget_crn_full_merged'
OUT.mkdir(exist_ok=True)
chunks=[HERE/f'crn_{a:03d}_{a+99:03d}' for a in range(0,1000,100)]
raw=pd.concat([pd.read_csv(c/'raw_equal_budget_crn.csv') for c in chunks],ignore_index=True)
meta=pd.concat([pd.read_csv(c/'matched_schedules_crn.csv') for c in chunks],ignore_index=True)
val=pd.concat([pd.read_csv(c/'validation_crn.csv') for c in chunks],ignore_index=True)

# Structural checks
assert len(raw)==6000, len(raw)
assert len(meta)==2000, len(meta)
assert len(val)==2000, len(val)
assert not raw.duplicated(['case','seed','timing_label']).any()
assert not meta.duplicated(['case','seed']).any()
for case in ['CaseA_50_50','CaseB_80_20']:
    seeds=sorted(meta.loc[meta.case==case,'seed'].astype(int).tolist())
    assert seeds==list(range(1000)), (case,seeds[:3],seeds[-3:],len(seeds))
checkcols=[c for c in val.columns if c not in ['case','seed']]
assert (val[checkcols].min()==1).all(), val[checkcols].min()

raw.to_csv(OUT/'raw_equal_budget_crn_1000.csv',index=False)
meta.to_csv(OUT/'matched_schedules_crn_1000.csv',index=False)
val.to_csv(OUT/'validation_crn_1000.csv',index=False)

# Cell summaries
summary=[]
for (case,timing),g in raw.groupby(['case','timing_label']):
    rec=g['recovery_time_s'].dropna().astype(float)
    fs=g['final_stable_agreement_after_rejoin_s'].dropna().astype(float)
    summary.append(dict(case=case,timing_label=timing,n=len(g),
        final_agreement_rate=g.success_end.mean(),recovered_rate=g.recovered.mean(),
        recovery_mean_s=rec.mean(),recovery_median_s=rec.median(),recovery_p95_s=rec.quantile(.95),
        agreement_fraction_mean=g.post_rejoin_agreement_fraction.mean(),
        post_recovery_divergence_rate=g.post_recovery_diverged.mean(),
        agreement_loss_episodes_mean=g.agreement_loss_episodes.mean(),
        final_stable_available_rate=g.final_stable_agreement_after_rejoin_s.notna().mean(),
        final_stable_mean_s=fs.mean() if len(fs) else np.nan))
pd.DataFrame(summary).to_csv(OUT/'cell_summary_crn_1000.csv',index=False)

# Paired comparisons
rng=np.random.default_rng(20260906)
def boot_mean_ci(d,nboot=20000):
    d=np.asarray(d,dtype=float); n=len(d)
    idx=rng.integers(0,n,size=(nboot,n))
    means=d[idx].mean(axis=1)
    return float(d.mean()),float(np.quantile(means,.025)),float(np.quantile(means,.975))

def mcnemar_exact(a,b):
    # a,b binary; discordant b10 = A success B fail, b01=A fail B success
    a=np.asarray(a,dtype=int); b=np.asarray(b,dtype=int)
    b10=int(((a==1)&(b==0)).sum()); b01=int(((a==0)&(b==1)).sum())
    n=b10+b01
    p=1.0 if n==0 else float(binomtest(min(b10,b01),n,.5,alternative='two-sided').pvalue)
    return b10,b01,p

pairs=[('Adaptive','FixedMatched'),('Adaptive','DisruptionWindowMatched'),('DisruptionWindowMatched','FixedMatched')]
rows=[]
for case,gcase in raw.groupby('case'):
    piv=gcase.pivot(index='seed',columns='timing_label')
    for A,B in pairs:
        sa=piv['success_end'][A].astype(int).values; sb=piv['success_end'][B].astype(int).values
        d=sa-sb; md,lo,hi=boot_mean_ci(d)
        b10,b01,p=mcnemar_exact(sa,sb)
        # recovery all are expected present, but pairwise complete for safety
        ra=piv['recovery_time_s'][A]; rb=piv['recovery_time_s'][B]; mask=ra.notna()&rb.notna()
        rdiff=(ra[mask]-rb[mask]).astype(float).values; rm,rlo,rhi=boot_mean_ci(rdiff)
        af=(piv['post_rejoin_agreement_fraction'][A]-piv['post_rejoin_agreement_fraction'][B]).astype(float).values
        am,alo,ahi=boot_mean_ci(af)
        loss=(piv['agreement_loss_episodes'][A]-piv['agreement_loss_episodes'][B]).astype(float).values
        lm,llo,lhi=boot_mean_ci(loss)
        rows.append(dict(case=case,A=A,B=B,n=1000,
            final_agreement_A=sa.mean(),final_agreement_B=sb.mean(),final_agreement_diff=md,
            final_diff_ci_low=lo,final_diff_ci_high=hi,mcnemar_A_success_B_fail=b10,
            mcnemar_A_fail_B_success=b01,mcnemar_exact_p=p,
            recovery_paired_n=int(mask.sum()),recovery_diff_A_minus_B_mean_s=rm,
            recovery_diff_ci_low_s=rlo,recovery_diff_ci_high_s=rhi,
            agreement_fraction_diff_A_minus_B=am,agreement_fraction_ci_low=alo,agreement_fraction_ci_high=ahi,
            agreement_loss_episode_diff_A_minus_B=lm,agreement_loss_ci_low=llo,agreement_loss_ci_high=lhi))
pd.DataFrame(rows).to_csv(OUT/'paired_comparisons_crn_1000.csv',index=False)

# Budget/baseline diagnostics
bd=[]
for case,g in meta.groupby('case'):
    bd.append(dict(case=case,n=len(g),budget_mean=g.adaptive_budget_total.mean(),budget_median=g.adaptive_budget_total.median(),
        budget_min=g.adaptive_budget_total.min(),budget_max=g.adaptive_budget_total.max(),
        adaptive_high_ticks_mean=g.adaptive_high_ticks.mean(),
        fraction_needing_prepartition_window=(g.disruption_pre_high_ticks>0).mean(),
        disruption_pre_high_ticks_mean=g.disruption_pre_high_ticks.mean(),
        disruption_post_high_ticks_mean=g.disruption_post_high_ticks.mean(),
        connected_pre_ticks=int(g.connected_pre_ticks.iloc[0]),connected_post_ticks=int(g.connected_post_ticks.iloc[0])))
pd.DataFrame(bd).to_csv(OUT/'budget_diagnostics_crn_1000.csv',index=False)

# concise report
summ=pd.DataFrame(summary); comp=pd.DataFrame(rows); bud=pd.DataFrame(bd)
lines=['# CRN 1000-seed central timing analysis','',
       'Structural validation: PASS (6000 runs; 2000 Case×seed bundles; seeds 0–999 complete in both cases).','']
for case in ['CaseA_50_50','CaseB_80_20']:
    lines.append(f'## {case}')
    for _,r in summ[summ.case==case].sort_values('timing_label').iterrows():
        lines.append(f"- {r.timing_label}: final={r.final_agreement_rate:.3f}; recovery mean={r.recovery_mean_s:.2f}s; agreement fraction={r.agreement_fraction_mean:.4f}; post-recovery divergence={r.post_recovery_divergence_rate:.3f}")
    lines.append('')
    for _,r in comp[comp.case==case].iterrows():
        lines.append(f"- {r.A} vs {r.B}: final diff={r.final_agreement_diff:+.3f} [{r.final_diff_ci_low:+.3f},{r.final_diff_ci_high:+.3f}], McNemar p={r.mcnemar_exact_p:.4g}; recovery A-B={r.recovery_diff_A_minus_B_mean_s:+.2f}s [{r.recovery_diff_ci_low_s:+.2f},{r.recovery_diff_ci_high_s:+.2f}]; agreement-fraction diff={r.agreement_fraction_diff_A_minus_B:+.4f} [{r.agreement_fraction_ci_low:+.4f},{r.agreement_fraction_ci_high:+.4f}]")
    br=bud[bud.case==case].iloc[0]
    lines.append(f"- Budget: mean={br.budget_mean:.1f}, median={br.budget_median:.1f}; {br.fraction_needing_prepartition_window:.1%} of seeds require a pre-partition high-rate window to preserve Adaptive's exact low/high count.")
    lines.append('')
(OUT/'analysis_report.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
