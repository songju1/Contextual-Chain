#!/usr/bin/env python3
"""CRN equal-budget timing study with a deterministic disruption-window baseline.

Full head rule only for the central timing attribution test.
For each Case x seed:
  1) run native Adaptive and record its connected-tick schedule,
  2) build FixedMatched by spreading the exact same assigned budget nearly uniformly,
  3) build DisruptionWindowMatched using the same number of low/high ticks, placing high
     ticks immediately after rejoin and, only when necessary to preserve the exact Adaptive
     budget, immediately before partition onset.
All three runs use keyed CRN streams, so proposal, broadcast-channel, and gossip-opportunity
external traces are identical for a matched Case x seed whenever total opportunity count matches.
"""
from __future__ import annotations
import csv, hashlib, math, os, sys, time
from multiprocessing import Pool
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Sequence, Tuple

HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))
from sim_context_chain_v6_crn import simulate

TIMINGS=('Adaptive','FixedMatched','DisruptionWindowMatched')

def env_int(n,d):
    x=os.getenv(n); return d if x in {None,''} else int(x)
def env_bool(n,d):
    x=os.getenv(n)
    if x in {None,''}: return d
    return x.strip().lower() in {'1','true','yes','y','on'}
def env_str(n,d):
    x=os.getenv(n); return d if x in {None,''} else x

def digest_schedule(s:Sequence[int])->str:
    return hashlib.sha256(bytes(int(x) for x in s)).hexdigest()

def balanced_uniform_schedule(total:int,ticks:int)->Tuple[int,...]:
    base,rem=divmod(total,ticks)
    out=[]; prev=0
    for i in range(ticks):
        cur=((i+1)*rem)//ticks
        out.append(base+(cur-prev)); prev=cur
    assert len(out)==ticks and sum(out)==total
    return tuple(out)

def disruption_window_matched_schedule(adaptive:Sequence[int], tick_times:Sequence[float],
                                         partition:Tuple[float,float], low:int=1, high:int=4)->Tuple[int,...]:
    if len(adaptive)!=len(tick_times): raise ValueError('schedule/time length mismatch')
    if any(x not in {low,high} for x in adaptive): raise ValueError('Adaptive schedule must use only low/high rates')
    H=sum(1 for x in adaptive if x==high)
    out=[low]*len(adaptive)
    # First place high-rate ticks in one deterministic window immediately after rejoin.
    post=[i for i,t in enumerate(tick_times) if t >= partition[1]-1e-12]
    pre=[i for i,t in enumerate(tick_times) if t < partition[0]-1e-12]
    chosen=[]
    npost=min(H,len(post)); chosen.extend(post[:npost])
    rem=H-npost
    # If Adaptive used more high ticks than fit post-rejoin, preserve exact budget by using
    # a second window immediately before partition onset. This baseline uses only known
    # disruption boundaries, never q or any state-derived context signal.
    if rem:
        chosen.extend(sorted(pre, reverse=True)[:rem])
    if len(chosen)!=H: raise RuntimeError(f'cannot place H={H} high ticks')
    for i in chosen: out[i]=high
    assert sum(out)==sum(adaptive)
    assert sum(x==high for x in out)==H
    return tuple(out)

def parse_cases(raw,n_nodes):
    out=[]
    for tok in raw.replace(',',' ').split():
        t=tok.lower()
        if t in {'casea','casea_50_50','50_50','50/50'}: out.append(('CaseA_50_50',n_nodes//2))
        elif t in {'caseb','caseb_80_20','80_20','80/20'}: out.append(('CaseB_80_20',int(round(.8*n_nodes))))
        else: raise ValueError(tok)
    seen=set(); return [x for x in out if not (x[0] in seen or seen.add(x[0]))]

def common_kwargs():
    n_nodes=env_int('N_NODES',20)
    return dict(
        n_nodes=n_nodes,block_interval_s=30.0,sim_time_s=3600.0,partition=(1200.0,2400.0),
        epoch_len_blocks=30,cp_epoch_mode='height',cp_tiebreak='none',L_score_window=40,
        K_converge=30,use_quarantine=True,conservative_switching=False,adaptive_q_threshold=.25,
        net_delay_mean=.80,net_delay_jitter=.20,net_drop_p=.02,gossip_tick_s=1.0,
        gossip_pairs_normal=1,gossip_pairs_quarantine=4,block_bytes_est=250,
        head_rule='full',return_trace_hashes=True,monitor_interval_s=1.0,
    )

def run_one(case,a_size,seed,common):
    base=dict(common,A_size=a_size,seed=seed)
    adaptive=simulate(**base,sync_policy='adaptive',return_sync_schedule=True)
    a_sched=tuple(adaptive['sync_schedule_trace']); times=tuple(adaptive['sync_tick_times_trace'])
    B=sum(a_sched); T=len(a_sched)
    fixed=balanced_uniform_schedule(B,T)
    dw=disruption_window_matched_schedule(a_sched,times,common['partition'],common['gossip_pairs_normal'],common['gossip_pairs_quarantine'])
    fixed_res=simulate(**base,sync_policy='fixed_matched_replay',sync_schedule_replay=fixed)
    dw_res=simulate(**base,sync_policy='fixed_matched_replay',sync_schedule_replay=dw)
    results={'Adaptive':adaptive,'FixedMatched':fixed_res,'DisruptionWindowMatched':dw_res}
    schedules={'Adaptive':a_sched,'FixedMatched':fixed,'DisruptionWindowMatched':dw}
    rows=[]
    for label in TIMINGS:
        r=results[label]
        rows.append(dict(
            case=case,A_size=a_size,seed=seed,pair_id=f'{case}:seed{seed}',timing_label=label,
            success_end=int(bool(r['heads_equal_end'])),recovered=int(r['recovery_time_s'] is not None),
            recovery_time_s=r['recovery_time_s'],converged_at_s=r['converged_at_s'],
            first_sustained_agreement_start_after_rejoin_s=r['first_sustained_agreement_start_after_rejoin_s'],
            post_rejoin_agreement_fraction=r['post_rejoin_agreement_fraction'],
            post_recovery_diverged=int(bool(r['post_recovery_diverged'])),
            agreement_loss_episodes=r['agreement_loss_episodes'],
            final_stable_agreement_after_rejoin_s=r['final_stable_agreement_after_rejoin_s'],
            max_reorg_depth=r['max_reorg_depth'],max_fork_peak=r['max_fork_peak'],
            gossip_budget_pair_draws=r['gossip_budget_pair_draws'],gossip_pairs=r['gossip_pairs'],
            gossip_blocks_sent=r['gossip_blocks_sent'],sync_schedule_hash=digest_schedule(schedules[label]),
            proposal_trace_hash=r['proposal_trace_hash'],broadcast_trace_hash=r['broadcast_trace_hash'],
            gossip_opportunity_trace_hash=r['gossip_opportunity_trace_hash'],
        ))
    H=sum(x==common['gossip_pairs_quarantine'] for x in a_sched)
    post_high=sum(1 for x,t in zip(dw,times) if t>=common['partition'][1]-1e-12 and x==common['gossip_pairs_quarantine'])
    pre_high=sum(1 for x,t in zip(dw,times) if t<common['partition'][0]-1e-12 and x==common['gossip_pairs_quarantine'])
    meta=dict(case=case,A_size=a_size,seed=seed,schedule_len=T,adaptive_budget_total=B,adaptive_high_ticks=H,
              connected_pre_ticks=sum(t<common['partition'][0]-1e-12 for t in times),
              connected_post_ticks=sum(t>=common['partition'][1]-1e-12 for t in times),
              disruption_post_high_ticks=post_high,disruption_pre_high_ticks=pre_high,
              adaptive_schedule_hash=digest_schedule(a_sched),fixed_schedule_hash=digest_schedule(fixed),
              disruption_schedule_hash=digest_schedule(dw))
    return rows,meta

def validate(rows,metas):
    bad=[]; checks=[]
    G=defaultdict(list)
    for r in rows:G[(r['case'],int(r['seed']))].append(r)
    for m in metas:
        key=(m['case'],int(m['seed'])); g=G[key]
        labels={r['timing_label'] for r in g}
        B=int(m['adaptive_budget_total'])
        budget=all(int(r['gossip_budget_pair_draws'])==B for r in g)
        prop=len({r['proposal_trace_hash'] for r in g})==1
        broad=len({r['broadcast_trace_hash'] for r in g})==1
        gossip=len({r['gossip_opportunity_trace_hash'] for r in g})==1
        frac=all(0.0 <= float(r['post_rejoin_agreement_fraction']) <= 1.0 for r in g)
        stable=all((r['final_stable_agreement_after_rejoin_s'] in {None,''} or float(r['final_stable_agreement_after_rejoin_s'])>=0) for r in g)
        c=dict(case=key[0],seed=key[1],three_cells=int(labels==set(TIMINGS) and len(g)==3),equal_budget=int(budget),
               proposal_trace_match=int(prop),broadcast_trace_match=int(broad),gossip_trace_match=int(gossip),
               agreement_fraction_valid=int(frac),stable_time_valid=int(stable))
        checks.append(c)
        if not all(int(v) for k,v in c.items() if k not in {'case','seed'}): bad.append(c)
    return checks,bad

def write_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def summarize(rows):
    G=defaultdict(list)
    for r in rows:G[(r['case'],r['timing_label'])].append(r)
    out=[]
    for (case,label),g in sorted(G.items()):
        rec=[float(r['recovery_time_s']) for r in g if r['recovery_time_s'] not in {None,''}]
        out.append(dict(case=case,timing_label=label,n=len(g),final_agreement_rate=mean(int(r['success_end']) for r in g),
                        recovery_mean_s=mean(rec) if rec else float('nan'),
                        agreement_fraction_mean=mean(float(r['post_rejoin_agreement_fraction']) for r in g),
                        post_recovery_divergence_rate=mean(int(r['post_recovery_diverged']) for r in g)))
    return out

def _worker(job):
    case,a,seed,common=job
    return run_one(case,a,seed,common)

def main():
    common=common_kwargs(); smoke=env_bool('SMOKE',False); n=env_int('NSEEDS',10 if smoke else 1000); start=env_int('SEED_START',0)
    cases=parse_cases(env_str('EXTRA_CASES','CaseA_50_50 CaseB_80_20'),common['n_nodes'])
    out=Path(env_str('OUTDIR',str(HERE/f"equal_budget_crn_{time.strftime('%Y%m%d_%H%M%S')}"))).resolve(); out.mkdir(parents=True,exist_ok=True)
    rows=[]; metas=[]
    jobs=[(case,a,seed,common) for case,a in cases for seed in range(start,start+n)]
    workers=max(1,env_int('JOBS',min(5,os.cpu_count() or 1)))
    print(f'[INFO] cases={cases} seeds={start}..{start+n-1} workers={workers} out={out}')
    t0=time.perf_counter()
    if workers==1:
        bundles=map(_worker,jobs)
        for rr,mm in bundles: rows.extend(rr); metas.append(mm)
    else:
        with Pool(workers) as pool:
            for rr,mm in pool.imap_unordered(_worker,jobs,chunksize=2):
                rows.extend(rr); metas.append(mm)
    rows.sort(key=lambda r:(r['case'],int(r['seed']),TIMINGS.index(r['timing_label'])))
    metas.sort(key=lambda m:(m['case'],int(m['seed'])))
    checks,bad=validate(rows,metas)
    write_csv(out/'raw_equal_budget_crn.csv',rows); write_csv(out/'matched_schedules_crn.csv',metas); write_csv(out/'validation_crn.csv',checks); write_csv(out/'summary_crn.csv',summarize(rows))
    (out/'provenance.txt').write_text(
        f'created={time.strftime("%Y-%m-%d %H:%M:%S %z")}\nseeds={start}..{start+n-1}\n'
        f'simulator=sim_context_chain_v6_crn.py\nmonitor_interval_s=1.0\nsustained_observations=30\n'
        'DisruptionWindowMatched uses only known partition/rejoin boundaries and preserves the exact Adaptive low/high tick counts.\n'
    )
    if bad:
        print('[FAIL]',len(bad),bad[:3]); return 2
    print(f'[PASS] {len(metas)} bundles / {len(rows)} runs; elapsed={time.perf_counter()-t0:.2f}s')
    for x in summarize(rows): print(x)
    return 0
if __name__=='__main__': raise SystemExit(main())
