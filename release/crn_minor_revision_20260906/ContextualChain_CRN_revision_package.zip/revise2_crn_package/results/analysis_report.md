# CRN 1000-seed central timing analysis

Structural validation: PASS (6000 runs; 2000 Case×seed bundles; seeds 0–999 complete in both cases).

## CaseA_50_50
- Adaptive: final=0.832; recovery mean=90.52s; agreement fraction=0.8278; post-recovery divergence=1.000
- DisruptionWindowMatched: final=0.809; recovery mean=88.18s; agreement fraction=0.8292; post-recovery divergence=1.000
- FixedMatched: final=0.794; recovery mean=104.94s; agreement fraction=0.7832; post-recovery divergence=1.000

- Adaptive vs FixedMatched: final diff=+0.038 [+0.025,+0.051], McNemar p=1.618e-09; recovery A-B=-14.43s [-17.24,-11.75]; agreement-fraction diff=+0.0445 [+0.0420,+0.0470]
- Adaptive vs DisruptionWindowMatched: final diff=+0.023 [+0.014,+0.033], McNemar p=1.55e-06; recovery A-B=+2.33s [+1.27,+3.52]; agreement-fraction diff=-0.0014 [-0.0022,-0.0007]
- DisruptionWindowMatched vs FixedMatched: final diff=+0.015 [+0.001,+0.029], McNemar p=0.04887; recovery A-B=-16.76s [-19.56,-14.02]; agreement-fraction diff=+0.0460 [+0.0434,+0.0485]
- Budget: mean=6810.5, median=6003.0; 49.6% of seeds require a pre-partition high-rate window to preserve Adaptive's exact low/high count.

## CaseB_80_20
- Adaptive: final=0.834; recovery mean=84.28s; agreement fraction=0.8332; post-recovery divergence=1.000
- DisruptionWindowMatched: final=0.816; recovery mean=83.11s; agreement fraction=0.8339; post-recovery divergence=1.000
- FixedMatched: final=0.787; recovery mean=96.39s; agreement fraction=0.7889; post-recovery divergence=1.000

- Adaptive vs FixedMatched: final diff=+0.047 [+0.034,+0.061], McNemar p=1.179e-12; recovery A-B=-12.11s [-14.92,-9.38]; agreement-fraction diff=+0.0443 [+0.0418,+0.0469]
- Adaptive vs DisruptionWindowMatched: final diff=+0.018 [+0.009,+0.028], McNemar p=0.0001211; recovery A-B=+1.16s [+0.48,+1.92]; agreement-fraction diff=-0.0006 [-0.0013,-0.0000]
- DisruptionWindowMatched vs FixedMatched: final diff=+0.029 [+0.016,+0.043], McNemar p=5.704e-05; recovery A-B=-13.28s [-16.05,-10.62]; agreement-fraction diff=+0.0450 [+0.0424,+0.0475]
- Budget: mean=6813.6, median=6003.0; 49.6% of seeds require a pre-partition high-rate window to preserve Adaptive's exact low/high count.

