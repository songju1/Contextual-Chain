# Contextual Chain CRN revision package

This package is a new validation/extension layer. It does not modify the frozen v5 simulator or the previously released results.

## Code
- `sim_context_chain_v6_crn.py`: independent common-random-number streams plus fixed-time recovery monitoring.
- `validate_crn.py`: native Adaptive vs Adaptive replay vs FixedMatched trace validation.
- `run_equal_budget_crn.py`: Full-head-rule central timing study with Adaptive, FixedMatched, and DisruptionWindowMatched.
- `analyze_crn_full.py`: merge/validation and paired statistical analysis.

## Central design
- Proposal arrival streams are independent per node.
- Block-nonce streams are independent per node.
- Broadcast channel draws use a dedicated stream with fixed consumption per proposal-recipient pair.
- Gossip source/destination/drop uses a dedicated stream with fixed consumption per assigned pair opportunity.
- Gossip block-transfer draws are isolated within each opportunity, so variable suffix lengths cannot perturb later opportunities.
- Recovery is checked on 1-second monitor ticks; 30 consecutive observations of the same common head are required.
- `DisruptionWindowMatched` preserves each Adaptive run's exact total assigned budget and exact low/high tick counts, but uses only known partition/rejoin boundaries and never the quarantine fraction.

## Validation
- 20 Case×seed CRN smoke bundles passed all trace and replay checks.
- Full central study: 2 cases × 1000 seeds × 3 timing policies = 6000 runs.
- Merged structural validation confirms seeds 0–999 exactly once per case/timing cell and all budget/trace-structure checks passed.
